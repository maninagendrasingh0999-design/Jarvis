/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Mic,
  MicOff,
  Settings,
  MessageSquare,
  Sparkles,
  Zap,
  Globe,
  Radio,
  Volume2,
  VolumeX,
  Youtube,
  ExternalLink,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  X,
  Repeat,
  Send,
  Clock,
  RotateCcw,
  MapPin,
  Phone,
  Download,
  Key,
  Brain,
  Terminal,
  Code2,
  TrendingUp,
  Lock,
  Unlock,
  CircleDot,
} from 'lucide-react';
import { AndroidFrame } from './components/AndroidFrame';
import { VoiceOrb } from './components/VoiceOrb';
import { ChatInterface } from './components/ChatInterface';
import { DeviceControls } from './components/DeviceControls';
import { SettingsModal } from './components/SettingsModal';
import { AndroidBuildModal } from './components/AndroidBuildModal';
import { ApiKeyModal } from './components/ApiKeyModal';
import { CodeTerminalModal } from './components/CodeTerminalModal';
import { MemoryModal } from './components/MemoryModal';
import { CyberAuthScreen } from './components/CyberAuthScreen';
import { FloatingOrbOverlay } from './components/FloatingOrbOverlay';
import { CodingMasterModal } from './components/CodingMasterModal';
import { TradeMasterModal } from './components/TradeMasterModal';
import {
  AssistantLanguage,
  AssistantState,
  getJarvisGreeting,
  parseJarvisIntent,
  isInstantLocalCommand,
  generateOfflineJarvisResponse,
} from './utils/jarvis-core';
import { executeJarvisAction, executeStructuredAction, getNativeBridge } from './utils/action-executor';
import {
  playHudSound,
  getSpeechRecognition,
  mapLanguageToLocale,
  speakText,
  stopSpeaking,
} from './utils/audio';
import {
  ChatMessage,
  ReminderItem,
  SystemStatusData,
  VoiceSettings,
  ActionExecutionResult,
  CodeSolution,
  MemoryItem,
  StructuredAction,
  CyberAuthProfile,
  TradeMasterData,
} from './types';

export const DEFAULT_GEMINI_API_KEY = 'AIzaSyDNKMF5hhri9fvpU7DSgHyFKB7rdkxKaTI';

export default function App() {
  // Assistant states
  const [assistantState, setAssistantState] = useState<AssistantState>('idle');
  const [language, setLanguage] = useState<AssistantLanguage>('en');
  const [viewMode, setViewMode] = useState<'orb' | 'chat'>('orb');
  const [liveTranscript, setLiveTranscript] = useState<string>('');
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isBuildModalOpen, setIsBuildModalOpen] = useState<boolean>(false);
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState<string | null>(null);
  const [activeActionHUD, setActiveActionHUD] = useState<ActionExecutionResult | null>(null);
  const ttsAudioCacheRef = useRef<Map<string, string>>(new Map());
  const isProcessingRef = useRef<boolean>(false);

  // 1. Cyber Phone & PIN Security Profile State
  const [authProfile, setAuthProfile] = useState<CyberAuthProfile>(() => {
    try {
      const saved = localStorage.getItem('jarvis_cyber_auth');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      phoneNumber: '',
      pin: '',
      apiKey: '',
      isConfigured: false,
      rememberDevice: true,
    };
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  // 2. Screen-Side Robotic Arc-Reactor Floating Ball Widget State
  const [isFloatingOrbActive, setIsFloatingOrbActive] = useState<boolean>(true);

  // 3. Coding Master & Trade Master Modals State
  const [isCodingMasterOpen, setIsCodingMasterOpen] = useState<boolean>(false);
  const [isTradeMasterOpen, setIsTradeMasterOpen] = useState<boolean>(false);

  // Autonomous Agent States: API Key, Permanent Memory, Code Terminal
  const [apiKey, setApiKey] = useState<string>(() => {
    try {
      const stored = localStorage.getItem('jarvis_gemini_api_key');
      if (stored && stored.trim()) return stored.trim();
      const nativeKey = getNativeBridge()?.getApiKey?.();
      if (nativeKey && nativeKey.trim()) return nativeKey.trim();
      return DEFAULT_GEMINI_API_KEY;
    } catch (e) {
      return DEFAULT_GEMINI_API_KEY;
    }
  });
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState<boolean>(false);

  const [memories, setMemories] = useState<MemoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('jarvis_permanent_memory');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [
      {
        id: 'mem-1',
        key: 'system_directive',
        value: 'Autonomous AI Agent with full native device control, multi-turn dialogue, and coding engine.',
        createdAt: Date.now(),
      },
    ];
  });
  const [isMemoryModalOpen, setIsMemoryModalOpen] = useState<boolean>(false);

  const [activeCodeSolution, setActiveCodeSolution] = useState<CodeSolution | null>(null);
  const [isCodeTerminalOpen, setIsCodeTerminalOpen] = useState<boolean>(false);

  const handleAddMemory = useCallback((key: string, value: string) => {
    const newMem: MemoryItem = {
      id: `mem-${Date.now()}`,
      key,
      value,
      createdAt: Date.now(),
    };
    setMemories((prev) => {
      const updated = [newMem, ...prev.filter((m) => m.key !== key)];
      try {
        localStorage.setItem('jarvis_permanent_memory', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    const bridge = getNativeBridge();
    if (bridge && typeof bridge.saveMemory === 'function') {
      try {
        bridge.saveMemory(key, value);
      } catch (e) {}
    }
  }, []);

  const handleDeleteMemory = useCallback((id: string) => {
    setMemories((prev) => {
      const updated = prev.filter((m) => m.id !== id);
      try {
        localStorage.setItem('jarvis_permanent_memory', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  }, []);

  const [tradeMasterData, setTradeMasterData] = useState<TradeMasterData | null>(null);

  // User-triggered action launch handler (updates status honestly upon actual launch)
  const handleActionLaunched = useCallback((action: ActionExecutionResult) => {
    setActiveActionHUD((prev) =>
      prev
        ? {
            ...prev,
            status: 'executed',
            feedbackText: prev.payload?.query
              ? `YouTube tab launched successfully for "${prev.payload.query}".`
              : 'YouTube homepage launched successfully in a new browser tab.',
          }
        : null
    );
    setMessages((prev) =>
      prev.map((m) =>
        m.actionResult && m.actionResult.type === action.type
          ? {
              ...m,
              actionResult: {
                ...m.actionResult,
                status: 'executed',
                feedbackText: m.actionResult.payload?.query
                  ? `YouTube tab launched successfully for "${m.actionResult.payload.query}".`
                  : 'YouTube homepage launched successfully in a new browser tab.',
              },
            }
          : m
      )
    );
  }, []);

  // System backend status
  const [systemStatus, setSystemStatus] = useState<SystemStatusData | null>(null);

  // Voice Preferences
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>(() => {
    const defaults: VoiceSettings = {
      engine: 'browser',
      elevenLabsVoiceId: '21m00Tcm4TlvDq8ikWAM', // Rachel natural female
      preferredBrowserVoiceName: '',
      speechRate: 1.0,
      pitch: 1.05,
      autoSpeak: true,
      soundEffects: true,
      continuousConversation: true, // Mandatory: True Continuous Listening ON by default!
    };
    try {
      const saved = localStorage.getItem('jarvis_voice_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...defaults, ...parsed, continuousConversation: true };
      }
    } catch (e) {}
    return defaults;
  });

  // Cyber Auth handlers
  const handleAuthenticate = useCallback((profile: CyberAuthProfile) => {
    setAuthProfile(profile);
    setIsAuthenticated(true);
    if (profile.apiKey && !apiKey) {
      setApiKey(profile.apiKey);
    }
    if (voiceSettings.soundEffects) {
      playHudSound('startup');
    }
  }, [apiKey, voiceSettings.soundEffects]);

  const handleResetAuth = useCallback(() => {
    try {
      localStorage.removeItem('jarvis_cyber_auth');
    } catch (e) {}
    setAuthProfile({
      phoneNumber: '',
      pin: '',
      apiKey: '',
      isConfigured: false,
      rememberDevice: true,
    });
    setIsAuthenticated(false);
  }, []);

  const handleLockTerminal = useCallback(() => {
    setIsAuthenticated(false);
    if (voiceSettings.soundEffects) playHudSound('beep');
  }, [voiceSettings.soundEffects]);

  // Floating Orb Handler (Toggles Native Android Floating Service or Web Overlay)
  const handleToggleFloatingOrb = useCallback(() => {
    const bridge = getNativeBridge();
    if (bridge?.toggleFloatingOrb) {
      try {
        bridge.toggleFloatingOrb();
        const running = bridge.isFloatingOrbRunning ? bridge.isFloatingOrbRunning() : !isFloatingOrbActive;
        setIsFloatingOrbActive(running);
        return;
      } catch (e) {
        console.warn('Native floating orb toggle failed:', e);
      }
    }
    setIsFloatingOrbActive((prev) => !prev);
  }, [isFloatingOrbActive]);

  // Reminders store
  const [reminders, setReminders] = useState<ReminderItem[]>(() => {
    try {
      const saved = localStorage.getItem('jarvis_reminders');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [
      {
        id: 'init-1',
        text: 'Check Stark Systems Telemetry',
        dueTime: Date.now() + 15 * 60000,
        minutes: 15,
        completed: false,
        createdAt: Date.now(),
      },
    ];
  });

  // Messages log
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'welcome-0',
      sender: 'jarvis',
      text: getJarvisGreeting('en'),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      language: 'en',
      provider: 'offline_core',
    },
  ]);

  // Speech Recognition & Continuous Conversation States
  const [listeningSecondsLeft, setListeningSecondsLeft] = useState<number>(20);
  const [micPermissionError, setMicPermissionError] = useState<string | null>(null);

  // Speech Recognition Session Refs
  const recognitionRef = useRef<any>(null);
  const isListeningSessionRef = useRef<boolean>(false);
  const accumulatedTranscriptRef = useRef<string>('');
  const interimTranscriptRef = useRef<string>('');
  const sessionStartTimeRef = useRef<number>(0);
  const silenceTimerRef = useRef<any>(null);
  const maxDurationTimerRef = useRef<any>(null);
  const countdownIntervalRef = useRef<any>(null);
  const continuousLoopTimerRef = useRef<any>(null);
  const startListeningRef = useRef<() => void>(() => {});

  // Deduplication & safe recovery refs
  const lastSubmittedTextRef = useRef<string>('');
  const lastSubmittedTimeRef = useRef<number>(0);
  const consecutiveNoSpeechCountRef = useRef<number>(0);

  // Stop Listening Immediately (Discards pending transcript or ceases capture)
  const stopListeningImmediate = useCallback(() => {
    isListeningSessionRef.current = false;

    if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
    if (maxDurationTimerRef.current) clearTimeout(maxDurationTimerRef.current);
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    if (continuousLoopTimerRef.current) clearTimeout(continuousLoopTimerRef.current);

    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch (e) {}
      try {
        recognitionRef.current.stop();
      } catch (e) {}
    }

    setAssistantState('idle');
    setLiveTranscript('');
    if (voiceSettings.soundEffects) {
      playHudSound('beep');
    }
  }, [voiceSettings.soundEffects]);

  // Sync Voice Settings to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('jarvis_voice_settings', JSON.stringify(voiceSettings));
    } catch (e) {}
  }, [voiceSettings]);

  // Sync Reminders to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('jarvis_reminders', JSON.stringify(reminders));
    } catch (e) {}
  }, [reminders]);

  // Fetch backend status and auto-configure GEMINI_API_KEY fallback on mount
  useEffect(() => {
    fetch('/api/status')
      .then((res) => res.json())
      .then((data: SystemStatusData) => {
        setSystemStatus(data);
      })
      .catch((err) => {
        console.warn('Could not fetch /api/status:', err);
      });

    // Automatically fallback to process.env.GEMINI_API_KEY if localStorage key is empty
    fetch('/api/config')
      .then((res) => res.json())
      .then((cfg) => {
        if (cfg?.geminiKey) {
          setApiKey((current) => {
            if (!current) {
              try {
                localStorage.setItem('jarvis_gemini_api_key', cfg.geminiKey);
              } catch (e) {}
              return cfg.geminiKey;
            }
            return current;
          });
        }
      })
      .catch(() => {});
  }, []);

  // Monitor reminder countdowns and trigger alert chime
  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      setReminders((prev) =>
        prev.map((r) => {
          if (!r.completed && r.dueTime <= now) {
            if (voiceSettings.soundEffects) {
              playHudSound('alert');
            }
            // Add alert message to chat
            const alertMsg: ChatMessage = {
              id: `rem-alert-${Date.now()}`,
              sender: 'jarvis',
              text: `[PROTOCOL REMINDER ALERT]: ${r.text}. Time elapsed, Sir.`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              language,
              provider: 'system_alert',
            };
            setMessages((m) => [...m, alertMsg]);
            if (voiceSettings.autoSpeak) {
              speakResponse(alertMsg.text, language, alertMsg.id);
            }
            return { ...r, completed: true };
          }
          return r;
        })
      );
    }, 10000);

    return () => clearInterval(timer);
  }, [voiceSettings, language]);

  // Update initial greeting when language changes if no user messages yet
  const handleSelectLanguage = (newLang: AssistantLanguage) => {
    setLanguage(newLang);
    if (voiceSettings.soundEffects) playHudSound('beep');
    if (messages.length <= 1) {
      setMessages([
        {
          id: `greet-${Date.now()}`,
          sender: 'jarvis',
          text: getJarvisGreeting(newLang),
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          language: newLang,
          provider: 'offline_core',
        },
      ]);
    }
  };

  // Vocalize Response handler
  const speakResponse = useCallback(
    async (text: string, lang: AssistantLanguage, msgId: string) => {
      // 1. Immediately abort & stop any microphone recognition before speech playback starts!
      // This eliminates the acoustic feedback loop where JARVIS hears its own voice.
      stopListeningImmediate();

      setCurrentlySpeakingId(msgId);
      setAssistantState('speaking');

      const onSpeechPlaybackEnded = () => {
        setCurrentlySpeakingId(null);
        setAssistantState('idle');

        // Continuous Conversation Mode auto-restarts listening after JARVIS finishes speaking
        if (
          voiceSettings.continuousConversation &&
          !micPermissionError &&
          typeof document !== 'undefined' &&
          !document.hidden
        ) {
          if (continuousLoopTimerRef.current) clearTimeout(continuousLoopTimerRef.current);
          // 450ms pause to ensure speakers finish output buffer before microphone receptors reopen
          continuousLoopTimerRef.current = setTimeout(() => {
            startListeningRef.current?.();
          }, 450);
        }
      };

      // Check if ElevenLabs is selected AND configured
      if (voiceSettings.engine === 'elevenlabs' && systemStatus?.elevenLabsConfigured) {
        const cleanText = text.trim();
        const cacheKey = `${voiceSettings.elevenLabsVoiceId}:${cleanText}`;
        const cachedUrl = ttsAudioCacheRef.current.get(cacheKey);

        if (cachedUrl) {
          const audio = new Audio(cachedUrl);
          audio.onended = onSpeechPlaybackEnded;
          audio.onerror = () => speakWithBrowser(text, lang, msgId, onSpeechPlaybackEnded);
          audio.play().catch(() => speakWithBrowser(text, lang, msgId, onSpeechPlaybackEnded));
          return;
        }

        // Strict 2500ms timeout on ElevenLabs network call to prevent speech delays
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2500);

        try {
          const resp = await fetch('/api/tts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: controller.signal,
            body: JSON.stringify({
              text: cleanText,
              voiceId: voiceSettings.elevenLabsVoiceId,
            }),
          });
          clearTimeout(timeoutId);

          if (resp.ok && resp.headers.get('Content-Type')?.includes('audio')) {
            const blob = await resp.blob();
            const audioUrl = URL.createObjectURL(blob);
            ttsAudioCacheRef.current.set(cacheKey, audioUrl);
            const audio = new Audio(audioUrl);
            audio.onended = onSpeechPlaybackEnded;
            audio.onerror = () => {
              speakWithBrowser(text, lang, msgId, onSpeechPlaybackEnded);
            };
            audio.play().catch(() => speakWithBrowser(text, lang, msgId, onSpeechPlaybackEnded));
            return;
          }
        } catch (e) {
          clearTimeout(timeoutId);
          console.warn('ElevenLabs playback error or timeout, using browser synthesis:', e);
        }
      }

      // Default browser speech synthesis
      speakWithBrowser(text, lang, msgId, onSpeechPlaybackEnded);
    },
    [voiceSettings, systemStatus, micPermissionError]
  );

  const speakWithBrowser = (
    text: string,
    lang: AssistantLanguage,
    msgId: string,
    onEndedCallback?: () => void
  ) => {
    speakText(text, lang, {
      pitch: voiceSettings.pitch,
      rate: voiceSettings.speechRate,
      preferredVoiceName: voiceSettings.preferredBrowserVoiceName,
      onEnd: () => {
        if (onEndedCallback) {
          onEndedCallback();
        } else {
          setCurrentlySpeakingId(null);
          setAssistantState('idle');
        }
      },
      onError: () => {
        setCurrentlySpeakingId(null);
        setAssistantState('idle');
      },
    });
  };

  const handleStopSpeaking = () => {
    if (continuousLoopTimerRef.current) clearTimeout(continuousLoopTimerRef.current);
    stopSpeaking();
    setCurrentlySpeakingId(null);
    setAssistantState('idle');
  };

  // Dispatch message to Server API (/api/chat)
  const handleSendMessage = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || isProcessingRef.current) return;
    isProcessingRef.current = true;

    if (voiceSettings.soundEffects) {
      playHudSound('confirm');
    }

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: trimmed,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      language,
    };

    setMessages((prev) => [...prev, userMsg]);
    setLiveTranscript('');

    // Fast Instant Local Command Optimization:
    // Only intercept wake-words and time/date locally to preserve full Gemini natural language & multi-turn dialog
    const fastCheck = isInstantLocalCommand(trimmed, language);
    const isPurelyLocal =
      fastCheck.isInstant &&
      (fastCheck.intent.type === 'WAKE_WORD_TRIGGER' ||
        fastCheck.intent.type === 'STANDBY_MODE' ||
        fastCheck.intent.type === 'STOP_LISTENING' ||
        fastCheck.intent.type === 'TIME_QUERY' ||
        fastCheck.intent.type === 'DATE_QUERY');

    if (isPurelyLocal) {
      let actionResult: ActionExecutionResult | undefined = undefined;
      if (fastCheck.intent.type !== 'GENERAL_CHAT') {
        actionResult = executeJarvisAction(fastCheck.intent);
        setActiveActionHUD(actionResult);
      }
      if (fastCheck.intent.type === 'OPEN_SETTINGS') {
        setIsSettingsOpen(true);
      }
      if (fastCheck.intent.type === 'WAKE_WORD_TRIGGER') {
        setVoiceSettings((prev) => ({ ...prev, continuousConversation: true }));
      }
      if (fastCheck.intent.type === 'STANDBY_MODE') {
        setVoiceSettings((prev) => ({ ...prev, continuousConversation: false }));
        stopListeningImmediate();
        if (typeof window !== 'undefined' && (window as any).AndroidBridge?.enterStandby) {
          try {
            (window as any).AndroidBridge.enterStandby();
          } catch (e) {}
        }
      }
      if (fastCheck.intent.type === 'STOP_LISTENING') {
        setVoiceSettings((prev) => ({ ...prev, continuousConversation: false }));
        stopListeningImmediate();
        if (typeof window !== 'undefined' && (window as any).AndroidBridge?.stopVoiceService) {
          try {
            (window as any).AndroidBridge.stopVoiceService();
          } catch (e) {}
        }
      }

      const jarvisMsg: ChatMessage = {
        id: `jarvis-${Date.now()}`,
        sender: 'jarvis',
        text: fastCheck.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        language,
        intent: fastCheck.intent,
        actionResult,
        provider: 'instant_local_core',
      };

      setMessages((prev) => [...prev, jarvisMsg]);
      setAssistantState('idle');
      isProcessingRef.current = false;

      if (voiceSettings.autoSpeak) {
        speakResponse(jarvisMsg.text, language, jarvisMsg.id);
      }
      return;
    }

    setAssistantState('thinking');

    const effectiveKey = (
      apiKey ||
      (typeof localStorage !== 'undefined' ? localStorage.getItem('jarvis_gemini_api_key') : '') ||
      DEFAULT_GEMINI_API_KEY
    ).trim() || DEFAULT_GEMINI_API_KEY;

    let resolvedData: any = null;
    let exactErrorReason = '';

    // Step 1: Direct fast query to gemini-2.5-flash endpoint (replies instantly within 1 second)
    if (effectiveKey) {
      try {
        const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${effectiveKey}`;
        
        const historyText = messages
          .slice(-6)
          .map((m) => `${m.sender === 'user' ? 'User' : 'JARVIS'}: ${m.text}`)
          .join('\n');

        const systemPrompt = `You are J.A.R.V.I.S., the autonomous AI Assistant, Senior Software Engineer / App Developer, and PC Troubleshooter.
Current Language Mode: ${language.toUpperCase()}.
Respond in 1-2 natural sentences in ${language}. Address user as "Sir" or "Boss".
OUTPUT FORMAT: Always return valid JSON only (no markdown ticks):
{
  "reply": "Crisp spoken answer in ${language}",
  "action": null or { "type": "OPEN_APP" | "YOUTUBE_SEARCH_PLAY" | "WHATSAPP_SEND" | "MAKE_CALL" | "SET_ALARM" | "TOGGLE_TORCH" | "SYSTEM_SETTING", "params": { ... } },
  "codeSolution": null or { "title": "...", "language": "...", "code": "...", "explanation": "..." },
  "tradeData": null or { "symbol": "...", "tradeType": "...", "entryPrice": 0, "stopLossPrice": 0, "targetPrice": 0, "hinglishAdvice": "..." }
}`;

        const promptText = `${systemPrompt}\n\nCONVERSATION HISTORY:\n${historyText}\n\nUSER PROMPT: ${trimmed}`;

        const abortCtrl = new AbortController();
        const timeoutId = setTimeout(() => abortCtrl.abort(), 1800);

        let geminiResp = await fetch(geminiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: abortCtrl.signal,
          body: JSON.stringify({
            contents: [
              {
                role: 'user',
                parts: [{ text: promptText }],
              },
            ],
            generationConfig: {
              temperature: 0.3,
              maxOutputTokens: 200,
              responseMimeType: 'application/json',
            },
          }),
        });
        clearTimeout(timeoutId);

        let jsonResp = await geminiResp.json();

        // If Google returns 404 (deprecated for new users) or 503, seamlessly query gemini-flash-lite-latest or gemini-3.8-flash
        if (!geminiResp.ok && (geminiResp.status === 404 || geminiResp.status === 503 || jsonResp?.error?.message?.includes('no longer available'))) {
          try {
            const fbCtrl = new AbortController();
            const fbTimeout = setTimeout(() => fbCtrl.abort(), 1500);
            const fallbackUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-lite-latest:generateContent?key=${effectiveKey}`;
            geminiResp = await fetch(fallbackUrl, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              signal: fbCtrl.signal,
              body: JSON.stringify({
                contents: [{ role: 'user', parts: [{ text: promptText }] }],
                generationConfig: { temperature: 0.3, maxOutputTokens: 200, responseMimeType: 'application/json' },
              }),
            });
            clearTimeout(fbTimeout);
            jsonResp = await geminiResp.json();
          } catch (e) {}
        }

        if (!geminiResp.ok) {
          throw new Error(jsonResp?.error?.message || `HTTP ${geminiResp.status}`);
        }

        const candidateText = jsonResp?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || '';
        let parsed: any = null;
        try {
          parsed = JSON.parse(candidateText);
        } catch (e) {
          const match = candidateText.match(/\{[\s\S]*\}/);
          if (match) {
            try { parsed = JSON.parse(match[0]); } catch (err) {}
          }
        }

        if (parsed && typeof parsed === 'object') {
          resolvedData = {
            reply: parsed.reply || candidateText || 'Task acknowledged, Sir.',
            action: parsed.action || null,
            codeSolution: parsed.codeSolution || null,
            tradeData: parsed.tradeData || null,
            provider: 'gemini-2.5-flash-direct',
          };
        } else if (candidateText) {
          resolvedData = {
            reply: candidateText,
            action: null,
            provider: 'gemini-2.5-flash-direct',
          };
        }
      } catch (directErr: any) {
        exactErrorReason = directErr?.message || 'Gemini direct error';
        console.warn('Direct Gemini 2.5 Flash attempt:', exactErrorReason);
      }
    }

    // Step 2: Fallback to /api/chat if direct call didn't succeed (uses server GEMINI_API_KEY)
    if (!resolvedData) {
      try {
        const chatController = new AbortController();
        const chatTimeout = setTimeout(() => {
          try { chatController.abort(); } catch (e) {}
        }, 4000);

        const resp = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: chatController.signal,
          body: JSON.stringify({
            message: trimmed,
            history: messages.slice(-8).map((m) => ({ role: m.sender, text: m.text })),
            language,
            apiKey: effectiveKey,
            memories: memories.map((m) => ({ key: m.key, value: m.value })),
          }),
        });
        clearTimeout(chatTimeout);

        if (resp.ok) {
          resolvedData = await resp.json();
        } else {
          const errData = await resp.json().catch(() => ({}));
          exactErrorReason = errData.error || `Server HTTP ${resp.status}`;
        }
      } catch (err: any) {
        if (!exactErrorReason) {
          exactErrorReason = err?.message || 'Server link unreachable';
        }
      }
    }

    try {
      // Step 3: If API failed for ANY reason, NEVER stay silent!
      if (!resolvedData || !resolvedData.reply) {
        const localIntent = parseJarvisIntent(trimmed, language);
        let localActionResult: ActionExecutionResult | undefined = undefined;
        if (localIntent && localIntent.type !== 'GENERAL_CHAT' && localIntent.type !== 'SYSTEM_STATUS') {
          localActionResult = executeJarvisAction(localIntent);
          setActiveActionHUD(localActionResult);
        }

        const smartReply = generateOfflineJarvisResponse(
          trimmed,
          language,
          exactErrorReason ? `API link (${exactErrorReason})` : undefined
        );

        resolvedData = {
          reply: smartReply,
          action: localIntent?.type !== 'GENERAL_CHAT' ? { type: localIntent.type, params: localIntent.payload } : null,
          actionResult: localActionResult,
          provider: 'smart_instant_fallback',
        };
      }

      // Execute structured action autonomously without requiring a user tap
      let actionResult: ActionExecutionResult | undefined = resolvedData.actionResult;
      if (!actionResult && resolvedData.action) {
        actionResult = executeStructuredAction(resolvedData.action);
        setActiveActionHUD(actionResult);
      } else if (
        !actionResult &&
        resolvedData.intent &&
        resolvedData.intent.type !== 'GENERAL_CHAT' &&
        resolvedData.intent.type !== 'SYSTEM_STATUS'
      ) {
        actionResult = executeJarvisAction(resolvedData.intent);
        setActiveActionHUD(actionResult);
      }

      // Permanent Memory storage
      if (resolvedData.memoryToSave && resolvedData.memoryToSave.key && resolvedData.memoryToSave.value) {
        handleAddMemory(resolvedData.memoryToSave.key, resolvedData.memoryToSave.value);
      }

      // Coding / PC Troubleshooting Solution Terminal
      if (resolvedData.codeSolution) {
        setActiveCodeSolution(resolvedData.codeSolution);
        setIsCodeTerminalOpen(true);
      }

      // Trade Master Engine trigger
      if (resolvedData.tradeData) {
        setTradeMasterData(resolvedData.tradeData);
        setIsTradeMasterOpen(true);
      }

      const jarvisMsg: ChatMessage = {
        id: `jarvis-${Date.now()}`,
        sender: 'jarvis',
        text: resolvedData.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        language: resolvedData.language || language,
        intent: resolvedData.intent,
        action: resolvedData.action,
        codeSolution: resolvedData.codeSolution,
        actionResult,
        provider: resolvedData.provider || 'gemini-2.5-flash',
      };

      setMessages((prev) => [...prev, jarvisMsg]);
      setAssistantState('idle');

      // ALWAYS vocalize response immediately (NEVER SILENT)
      if (voiceSettings.autoSpeak) {
        speakResponse(jarvisMsg.text, language, jarvisMsg.id);
      }
    } catch (unexpectedErr: any) {
      console.error('Unexpected dispatch failure:', unexpectedErr);
      setAssistantState('idle');
      const fallbackText = generateOfflineJarvisResponse(trimmed, language, unexpectedErr?.message);
      const errFallbackMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'jarvis',
        text: fallbackText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        language,
        provider: 'offline_emergency_core',
      };
      setMessages((prev) => [...prev, errFallbackMsg]);
      if (voiceSettings.autoSpeak) {
        speakResponse(errFallbackMsg.text, language, errFallbackMsg.id);
      }
    } finally {
      isProcessingRef.current = false;
    }
  };

  // Finalize Spoken Input and Send Command
  const finalizeAndSendCommand = useCallback(
    (forcedText?: string) => {
      isListeningSessionRef.current = false;

      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (maxDurationTimerRef.current) clearTimeout(maxDurationTimerRef.current);
      if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);

      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {}
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }

      const fullCandidate = forcedText !== undefined
        ? forcedText
        : (accumulatedTranscriptRef.current + ' ' + (interimTranscriptRef.current || '')).trim();

      // Filter out empty or placeholder text
      const cleanSpoken = fullCandidate
        .replace(/^Listening.*$/i, '')
        .replace(/^सुन रहा.*$/i, '')
        .replace(/^Receptors listening.*$/i, '')
        .trim();

      if (cleanSpoken.length >= 2) {
        // Prevent duplicate speech recognition results:
        // Ignore identical utterances submitted within 3.5 seconds
        const now = Date.now();
        if (
          cleanSpoken.toLowerCase() === lastSubmittedTextRef.current.toLowerCase() &&
          now - lastSubmittedTimeRef.current < 3500
        ) {
          return;
        }
        lastSubmittedTextRef.current = cleanSpoken;
        lastSubmittedTimeRef.current = now;
        consecutiveNoSpeechCountRef.current = 0;

        setLiveTranscript(cleanSpoken);
        handleSendMessage(cleanSpoken);
      } else {
        setAssistantState('idle');
        // If continuous mode is enabled but no speech was detected, track retries to avoid runaway loops
        if (voiceSettings.continuousConversation) {
          consecutiveNoSpeechCountRef.current++;
          if (consecutiveNoSpeechCountRef.current >= 3) {
            setLiveTranscript(
              language === 'hi'
                ? 'लगातार मोड रुका: कोई आवाज़ नहीं मिली। शुरू करने के लिए माइक दबाएँ।'
                : language === 'hinglish'
                ? 'Continuous mode idle: No speech detected. Tap mic to resume.'
                : 'Continuous mode idle: No speech detected. Tap microphone to resume.'
            );
            return;
          }
        }
        setLiveTranscript(
          language === 'hi'
            ? 'कोई आदेश नहीं सुना गया। पुनः प्रयास करें।'
            : language === 'hinglish'
            ? 'Koi command nahi suna gaya. Tap to retry.'
            : 'No voice command detected. Tap mic to retry.'
        );
        setTimeout(() => {
          setLiveTranscript('');
        }, 2500);
      }
    },
    [language, voiceSettings.continuousConversation, handleSendMessage]
  );

  // Manual Trigger to Send Currently Recognized Words Immediately
  const handleTransmitNow = useCallback(() => {
    const currentCandidate = (
      accumulatedTranscriptRef.current + ' ' + (interimTranscriptRef.current || '')
    ).trim();
    if (
      currentCandidate &&
      !currentCandidate.startsWith('Listening') &&
      !currentCandidate.startsWith('सुन रहा') &&
      !currentCandidate.startsWith('Receptors')
    ) {
      finalizeAndSendCommand(currentCandidate);
    } else {
      stopListeningImmediate();
    }
  }, [finalizeAndSendCommand, stopListeningImmediate]);

  // Start Resilient Continuous Listening Session (15–20s window, pause tolerant)
  const startListening = useCallback(() => {
    // Stop any active TTS audio immediately
    stopSpeaking();
    setCurrentlySpeakingId(null);

    // Clear any existing timers
    if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
    if (maxDurationTimerRef.current) clearTimeout(maxDurationTimerRef.current);
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    if (continuousLoopTimerRef.current) clearTimeout(continuousLoopTimerRef.current);

    const recognition = getSpeechRecognition();
    if (!recognition) {
      setMicPermissionError(
        'Speech recognition is not supported in this browser. Please use Google Chrome on desktop or Android.'
      );
      setAssistantState('error');
      return;
    }

    // Reset session buffers
    setMicPermissionError(null);
    accumulatedTranscriptRef.current = '';
    interimTranscriptRef.current = '';
    sessionStartTimeRef.current = Date.now();
    isListeningSessionRef.current = true;
    setListeningSecondsLeft(20);

    // Immediate prompt with feedback (True Continuous Mode, no auto-off limit)
    setLiveTranscript(
      language === 'hi'
        ? 'सुन रहा हूँ... लगातार मोड सक्रिय है (कभी भी बोलें)'
        : language === 'hinglish'
        ? 'Listening... Continuous mode active (speak anytime)'
        : 'Receptors active... Continuous mode engaged.'
    );
    setAssistantState('listening');

    if (voiceSettings.soundEffects) {
      playHudSound('listen');
    }

    recognition.lang = mapLanguageToLocale(language);
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognitionRef.current = recognition;

    recognition.onstart = () => {
      setAssistantState('listening');
    };

    recognition.onresult = (event: any) => {
      let currentFinal = '';
      let currentInterim = '';

      for (let i = 0; i < event.results.length; ++i) {
        const result = event.results[i];
        const transcriptChunk = result[0].transcript;
        if (result.isFinal) {
          currentFinal += transcriptChunk + ' ';
        } else {
          currentInterim += transcriptChunk;
        }
      }

      accumulatedTranscriptRef.current = currentFinal.trim();
      interimTranscriptRef.current = currentInterim.trim();

      const fullCurrentText = (
        accumulatedTranscriptRef.current + ' ' + (interimTranscriptRef.current || '')
      ).trim();

      consecutiveNoSpeechCountRef.current = 0;

      // Check for explicit stop command
      const lowerText = fullCurrentText.toLowerCase();
      if (
        lowerText.includes('stop listening') ||
        lowerText.includes('goodbye jarvis') ||
        lowerText.includes('goodbye') ||
        lowerText.includes('shut down') ||
        lowerText.includes('listen stop') ||
        lowerText.includes('stop') ||
        lowerText.includes('बंद करो') ||
        lowerText.includes('सुनना बंद करो')
      ) {
        stopListeningImmediate();
        return;
      }

      if (fullCurrentText) {
        setLiveTranscript(fullCurrentText);

        // SILENCE DEBOUNCE TIMER:
        // Wait 2.3 seconds of sustained silence after speech begins before auto-committing.
        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
        silenceTimerRef.current = setTimeout(() => {
          finalizeAndSendCommand();
        }, 2300);
      }
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        isListeningSessionRef.current = false;
        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
        if (continuousLoopTimerRef.current) clearTimeout(continuousLoopTimerRef.current);
        setMicPermissionError(
          'Microphone permission was denied by browser. Please grant microphone access in site settings to use voice commands.'
        );
        setAssistantState('error');
        setLiveTranscript('');
        return;
      }

      // True Continuous Listening: Immediately restart on no-speech or network-timeout without stopping!
      if (isListeningSessionRef.current && voiceSettings.continuousConversation && !micPermissionError) {
        setTimeout(() => {
          try {
            recognition.start();
          } catch (e) {}
        }, 150);
      }
    };

    recognition.onend = () => {
      // If user accumulated a complete sentence, commit it
      if (accumulatedTranscriptRef.current.trim().length >= 2) {
        finalizeAndSendCommand();
        return;
      }
      // True Continuous Listening: Keep microphone open in continuous mode indefinitely
      if (isListeningSessionRef.current && voiceSettings.continuousConversation && !micPermissionError) {
        setTimeout(() => {
          try {
            recognition.start();
          } catch (e) {}
        }, 150);
        return;
      }
      if (isListeningSessionRef.current) {
        finalizeAndSendCommand();
      }
    };

    try {
      recognition.start();
    } catch (e) {
      try {
        recognition.stop();
        setTimeout(() => {
          try {
            recognition.start();
          } catch (err) {}
        }, 150);
      } catch (err) {
        setAssistantState('idle');
      }
    }
  }, [language, voiceSettings.soundEffects, finalizeAndSendCommand, stopListeningImmediate, micPermissionError]);

  // Continuous Mode toggle handler: starts listening immediately when enabled
  const toggleContinuousMode = useCallback(
    (forced?: boolean) => {
      setVoiceSettings((prev) => {
        const nextVal = forced !== undefined ? forced : !prev.continuousConversation;
        if (prev.soundEffects) playHudSound(nextVal ? 'confirm' : 'beep');

        if (nextVal) {
          // Auto-start listening immediately without requiring repeated taps
          if (assistantState !== 'listening' && assistantState !== 'speaking') {
            setTimeout(() => {
              startListeningRef.current?.();
            }, 80);
          }
        } else {
          if (continuousLoopTimerRef.current) {
            clearTimeout(continuousLoopTimerRef.current);
            continuousLoopTimerRef.current = null;
          }
        }
        return { ...prev, continuousConversation: nextVal };
      });
    },
    [assistantState]
  );

  // Keep ref up to date for speech end callback
  useEffect(() => {
    startListeningRef.current = startListening;
  }, [startListening]);

  // Cleanup all timers on unmount
  useEffect(() => {
    return () => {
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (maxDurationTimerRef.current) clearTimeout(maxDurationTimerRef.current);
      if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
      if (continuousLoopTimerRef.current) clearTimeout(continuousLoopTimerRef.current);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {}
      }
    };
  }, []);

  // Retry Microphone Access Handler (explicit user gesture)
  const handleRetryMicPermission = async () => {
    setMicPermissionError(null);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
      }
      startListening();
    } catch (err) {
      setMicPermissionError(
        'Microphone permission blocked. Please enable microphone permissions in your browser bar.'
      );
    }
  };

  // Toggle Voice Input / Microphone (Instant response on tap)
  const handleToggleVoiceInput = useCallback(() => {
    if (assistantState === 'listening') {
      stopListeningImmediate();
      return;
    }

    if (assistantState === 'speaking') {
      handleStopSpeaking();
    }

    startListening();
  }, [assistantState, stopListeningImmediate, handleStopSpeaking, startListening]);

  // Global voice listener trigger for Floating Arc-Reactor Orb
  useEffect(() => {
    (window as any).triggerJarvisListening = () => {
      handleToggleVoiceInput();
    };
    return () => {
      delete (window as any).triggerJarvisListening;
    };
  }, [handleToggleVoiceInput]);

  const handleAddReminder = (text: string, minutes: number) => {
    const newRem: ReminderItem = {
      id: `rem-${Date.now()}`,
      text,
      minutes,
      dueTime: Date.now() + minutes * 60000,
      completed: false,
      createdAt: Date.now(),
    };
    setReminders((prev) => [newRem, ...prev]);
    if (voiceSettings.soundEffects) playHudSound('confirm');
  };

  const handleDeleteReminder = (id: string) => {
    setReminders((prev) => prev.filter((r) => r.id !== id));
  };

  // Requirement 1: Cyber Phone + 4-Digit Security PIN Gate
  if (!isAuthenticated) {
    return (
      <AndroidFrame activeLanguage={language}>
        <CyberAuthScreen
          authProfile={authProfile}
          onAuthenticateSuccess={handleAuthenticate}
          onResetAuth={handleResetAuth}
        />
      </AndroidFrame>
    );
  }

  return (
    <AndroidFrame activeLanguage={language}>
      {/* JARVIS Tactical HUD Header */}
      <header className="flex items-center justify-between pb-3 border-b border-cyan-500/25 shrink-0">
        <div className="flex items-center gap-2">
          <div className="relative flex items-center justify-center">
            <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-400 flex items-center justify-center shadow-[0_0_12px_#00e5ff]">
              <Radio className="w-4 h-4 text-cyan-300 animate-pulse" />
            </div>
            <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-black animate-ping" />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-hud text-sm font-bold tracking-wider text-white">
                J.A.R.V.I.S.
              </h1>
              <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-cyan-950/80 border border-cyan-500/40 text-cyan-300">
                ANDROID MK-VII
              </span>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400">
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                {systemStatus?.geminiConfigured ? 'Gemini AI' : 'Offline Neural Core'}
              </span>
              <span>•</span>
              <span className="text-cyan-400/80">Female Voice</span>
            </div>
          </div>
        </div>

        {/* Header Actions: Language, View Mode, Settings */}
        <div className="flex items-center gap-1.5">
          {/* Quick Language Switcher */}
          <div className="flex bg-slate-900 border border-cyan-500/30 rounded-lg p-0.5 text-[10px] font-tech font-semibold">
            {(['en', 'hi', 'hinglish'] as AssistantLanguage[]).map((l) => (
              <button
                key={l}
                onClick={() => handleSelectLanguage(l)}
                className={`px-1.5 py-0.5 rounded transition-all ${
                  language === l
                    ? 'bg-cyan-500 text-black font-bold shadow-[0_0_8px_#00e5ff]'
                    : 'text-slate-400 hover:text-white'
                }`}
                title={`Switch to ${l.toUpperCase()}`}
              >
                {l === 'en' ? 'EN' : l === 'hi' ? 'हिन्दी' : 'Hing'}
              </button>
            ))}
          </div>

          {/* Continuous Conversation Quick Toggle */}
          <button
            onClick={() => toggleContinuousMode()}
            className={`px-2 py-1 rounded-lg border text-[10px] font-mono flex items-center gap-1.5 transition-all cursor-pointer ${
              voiceSettings.continuousConversation
                ? 'bg-cyan-950 border-cyan-400 text-cyan-300 shadow-[0_0_10px_rgba(0,229,255,0.4)]'
                : 'bg-slate-900 border-cyan-500/20 text-slate-400 hover:text-white'
            }`}
            title="Toggle Continuous Hands-Free Conversation Loop"
            aria-label="Toggle continuous conversation loop"
          >
            <Repeat
              className={`w-3.5 h-3.5 ${
                voiceSettings.continuousConversation ? 'text-cyan-400 animate-spin-slow' : 'text-slate-400'
              }`}
            />
            <span className="hidden sm:inline">Loop:</span>
            <span className={voiceSettings.continuousConversation ? 'font-bold text-cyan-300' : 'text-slate-400'}>
              {voiceSettings.continuousConversation ? 'ON' : 'OFF'}
            </span>
          </button>

          {/* Toggle View Mode (Orb vs Chat) on Mobile */}
          <button
            onClick={() => {
              setViewMode(viewMode === 'orb' ? 'chat' : 'orb');
              if (voiceSettings.soundEffects) playHudSound('beep');
            }}
            className={`p-1.5 rounded-lg border transition-all ${
              viewMode === 'chat'
                ? 'bg-cyan-950 border-cyan-400 text-cyan-300'
                : 'bg-slate-900 border-cyan-500/30 text-slate-400 hover:text-white'
            }`}
            aria-label="Toggle between voice orb and chat history"
            title="Toggle View Mode"
          >
            <MessageSquare className="w-4 h-4" />
          </button>

          {/* Autonomous Code Solution Terminal Button */}
          {activeCodeSolution && (
            <button
              onClick={() => setIsCodeTerminalOpen(true)}
              className="p-1.5 rounded-lg bg-cyan-950/90 border border-cyan-400 text-cyan-300 hover:bg-cyan-900 transition-all flex items-center gap-1 text-[10px] font-mono shadow-[0_0_10px_rgba(0,229,255,0.4)] animate-pulse cursor-pointer"
              title="Open Coding Solution Terminal"
            >
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Terminal</span>
            </button>
          )}

          {/* Permanent Memory Manager Button */}
          <button
            onClick={() => setIsMemoryModalOpen(true)}
            className="p-1.5 rounded-lg bg-slate-900 border border-cyan-500/30 text-cyan-300 hover:text-white hover:border-cyan-400 transition-all flex items-center gap-1 text-[10px] font-mono cursor-pointer"
            title="JARVIS Permanent Memories"
          >
            <Brain className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Memory</span>
            <span className="text-[9px] px-1 rounded-full bg-cyan-500/20 text-cyan-300 font-bold">
              {memories.length}
            </span>
          </button>

          {/* Gemini API Key Button (Requirement #2: Prominently Visible 🔑 API Key button) */}
          <button
            onClick={() => setIsApiKeyModalOpen(true)}
            className={`px-2 py-1 rounded-lg border text-[11px] font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md ${
              apiKey
                ? 'bg-emerald-950/90 border-emerald-400 text-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                : 'bg-amber-950/90 border-amber-400 text-amber-200 animate-pulse shadow-[0_0_12px_rgba(245,158,11,0.5)]'
            }`}
            title="Configure Gemini API Key (Saved in localStorage with process.env.GEMINI_API_KEY fallback)"
          >
            <Key className={`w-3.5 h-3.5 ${apiKey ? 'text-emerald-400' : 'text-amber-400'}`} />
            <span>🔑 API Key</span>
            {apiKey && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
          </button>

          {/* Direct Download Pure Web Preview Source ZIP */}
          <a
            href="/web-source.zip"
            download="web-source.zip"
            className="p-1.5 rounded-lg bg-indigo-950/80 border border-indigo-400 text-indigo-300 hover:bg-indigo-900 transition-all flex items-center gap-1 text-[10px] font-mono shadow-[0_0_8px_rgba(99,102,241,0.3)] cursor-pointer"
            title="Download Pure Web Preview Source (web-source.zip)"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Web Source (.ZIP)</span>
          </a>

          {/* Direct Download Android Project ZIP & Cloud Build */}
          <button
            onClick={() => setIsBuildModalOpen(true)}
            className="p-1.5 rounded-lg bg-cyan-950/80 border border-cyan-400 text-cyan-300 hover:bg-cyan-900 transition-all flex items-center gap-1 text-[10px] font-mono shadow-[0_0_8px_rgba(0,229,255,0.3)] cursor-pointer"
            title="Download Verified Android Project (.ZIP)"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">APK Project (.ZIP)</span>
          </button>

          {/* Floating Ball Overlay Toggle */}
          <button
            onClick={handleToggleFloatingOrb}
            className={`p-1.5 rounded-lg border text-[10px] font-mono flex items-center gap-1 transition-all cursor-pointer ${
              isFloatingOrbActive
                ? 'bg-cyan-950/90 border-cyan-400 text-cyan-300 shadow-[0_0_10px_rgba(0,229,255,0.4)]'
                : 'bg-slate-900 border-cyan-500/20 text-slate-400 hover:text-white'
            }`}
            title="Toggle Robotic Floating Arc-Reactor Orb Widget"
          >
            <CircleDot className={`w-3.5 h-3.5 ${isFloatingOrbActive ? 'text-cyan-400 animate-pulse' : 'text-slate-400'}`} />
            <span className="hidden sm:inline">Floating Orb</span>
          </button>

          {/* Coding Master Studio */}
          <button
            onClick={() => setIsCodingMasterOpen(true)}
            className="p-1.5 rounded-lg bg-slate-900 border border-cyan-500/30 text-cyan-300 hover:text-white hover:border-cyan-400 transition-all flex items-center gap-1 text-[10px] font-mono cursor-pointer"
            title="Coding Master & PC Troubleshooting Studio"
          >
            <Code2 className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Coding</span>
          </button>

          {/* Trade Master Engine */}
          <button
            onClick={() => setIsTradeMasterOpen(true)}
            className="p-1.5 rounded-lg bg-slate-900 border border-cyan-500/30 text-cyan-300 hover:text-white hover:border-cyan-400 transition-all flex items-center gap-1 text-[10px] font-mono cursor-pointer"
            title="Trade Master Engine (Crypto/Stocks Risk & Hinglish Advice)"
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Trade</span>
          </button>

          {/* Settings Button */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="p-1.5 rounded-lg bg-slate-900 border border-cyan-500/30 text-slate-300 hover:text-cyan-300 hover:border-cyan-400 transition-all cursor-pointer"
            aria-label="Open JARVIS settings"
            title="Settings Portal"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* Lock Terminal Button */}
          <button
            onClick={handleLockTerminal}
            className="p-1.5 rounded-lg bg-slate-900 border border-rose-500/30 text-rose-300 hover:text-rose-200 hover:border-rose-400 transition-all cursor-pointer"
            title="Lock HUD Terminal"
            aria-label="Lock HUD Terminal"
          >
            <Lock className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Main View Area */}
      <main className="flex-1 flex flex-col justify-between py-2 space-y-3">
        {/* VIEW 1: VOICE ORB HUD MODE */}
        {viewMode === 'orb' ? (
          <div className="flex-1 flex flex-col justify-around">
            {/* Holographic Arc Reactor Voice Orb */}
            <div className="flex flex-col items-center justify-center">
              <VoiceOrb
                state={assistantState}
                onClick={handleToggleVoiceInput}
                isListening={assistantState === 'listening'}
              />

              {/* Prominent Continuous Conversation HUD Controller */}
              <div className="w-full max-w-sm mt-2 px-4">
                <div
                  className={`p-2.5 rounded-xl border transition-all ${
                    voiceSettings.continuousConversation
                      ? 'bg-cyan-950/80 border-cyan-400 shadow-[0_0_20px_rgba(0,229,255,0.25)]'
                      : 'bg-slate-950/70 border-cyan-500/25'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center border shrink-0 ${
                          voiceSettings.continuousConversation
                            ? 'bg-cyan-950 border-cyan-400 text-cyan-300 shadow-[0_0_8px_#00e5ff]'
                            : 'bg-slate-900 border-slate-700 text-slate-400'
                        }`}
                      >
                        <Repeat
                          className={`w-4 h-4 ${
                            voiceSettings.continuousConversation ? 'animate-spin-slow text-cyan-300' : ''
                          }`}
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-hud text-xs font-bold text-white tracking-wider">
                            CONTINUOUS MODE
                          </span>
                          <span
                            className={`text-[8px] font-mono px-1.5 py-0.2 rounded font-bold uppercase ${
                              voiceSettings.continuousConversation
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/50'
                                : 'bg-slate-900 text-slate-400 border border-slate-700'
                            }`}
                          >
                            {voiceSettings.continuousConversation ? 'ACTIVE' : 'OFF'}
                          </span>
                        </div>
                        <p className="text-[10px] font-mono text-slate-400 leading-tight">
                          {voiceSettings.continuousConversation
                            ? 'Auto-listens after JARVIS speaks'
                            : 'Enable for hands-free continuous dialogue'}
                        </p>
                      </div>
                    </div>

                    <button
                      role="switch"
                      aria-checked={voiceSettings.continuousConversation}
                      onClick={() => toggleContinuousMode()}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        voiceSettings.continuousConversation ? 'bg-cyan-500 shadow-[0_0_12px_#00e5ff]' : 'bg-slate-800'
                      }`}
                      title="Toggle Continuous Conversation Mode"
                      aria-label="Toggle Continuous Conversation Mode"
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-slate-950 border border-black shadow-md ring-0 transition duration-200 ease-in-out ${
                          voiceSettings.continuousConversation ? 'translate-x-5 bg-white' : 'translate-x-0 bg-slate-400'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>

              {/* Microphone Permission Denied Alert Banner */}
              {micPermissionError && (
                <div className="w-full max-w-sm mt-2 px-4 animate-in fade-in zoom-in-95">
                  <div className="p-3 rounded-xl border border-rose-500/60 bg-rose-950/85 shadow-[0_0_20px_rgba(244,63,94,0.3)] text-left">
                    <div className="flex items-center gap-2 text-rose-300 font-bold text-xs mb-1">
                      <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>MICROPHONE ACCESS DENIED</span>
                    </div>
                    <p className="text-[11px] font-mono text-rose-200/90 leading-tight mb-2.5">
                      {micPermissionError}
                    </p>
                    <button
                      onClick={handleRetryMicPermission}
                      className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-mono text-xs font-semibold flex items-center gap-1.5 shadow-[0_0_12px_rgba(244,63,94,0.5)] cursor-pointer transition-all"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Retry Microphone Access</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Live Speech Recognition / Capturing Banner */}
              <div className="w-full max-w-sm mt-1 px-4">
                {assistantState === 'listening' && (
                  <div className="flex items-center justify-between text-[10px] font-mono text-cyan-400 px-1 mb-1">
                    <span className="flex items-center gap-1.5 text-emerald-400">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      RECEPTORS ACTIVE (15-20S WINDOW)
                    </span>
                    <span className="flex items-center gap-1 text-cyan-300 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-500/40">
                      <Clock className="w-3 h-3 text-cyan-400" />
                      <span>{listeningSecondsLeft}s remaining</span>
                    </span>
                  </div>
                )}

                <div
                  className={`min-h-[48px] px-3.5 py-2.5 rounded-xl border text-center transition-all flex flex-col items-center justify-center ${
                    assistantState === 'listening'
                      ? 'bg-cyan-950/70 border-cyan-400 shadow-[0_0_25px_rgba(0,229,255,0.35)]'
                      : 'bg-slate-950/60 border-cyan-500/20'
                  }`}
                >
                  <p className="text-xs font-tech text-cyan-200 tracking-wide line-clamp-3">
                    {liveTranscript ||
                      (assistantState === 'thinking'
                        ? 'Synthesizing neural reply...'
                        : assistantState === 'speaking'
                        ? 'Broadcasting voice output...'
                        : messages.length > 0
                        ? `"${messages[messages.length - 1].text.slice(0, 100)}${
                            messages[messages.length - 1].text.length > 100 ? '...' : ''
                          }"`
                        : 'Tap the Orb or Mic to issue voice instructions')}
                  </p>
                  {assistantState === 'listening' && (
                    <span className="text-[9px] font-mono text-cyan-400/80 mt-1">
                      {liveTranscript &&
                      !liveTranscript.startsWith('Receptors') &&
                      !liveTranscript.startsWith('Listening') &&
                      !liveTranscript.startsWith('सुन रहा')
                        ? '✓ Speech captured — Pause to auto-send (2.3s) or tap SEND NOW'
                        : 'Brief sentence pauses will not stop listening'}
                    </span>
                  )}
                </div>

                {/* Tactical Listening Action Buttons: Large STOP LISTENING and SEND NOW */}
                {assistantState === 'listening' && (
                  <div className="flex flex-col gap-2 mt-2">
                    <button
                      onClick={stopListeningImmediate}
                      className="w-full py-3 px-4 rounded-xl bg-rose-950 hover:bg-rose-900 border-2 border-rose-500 text-rose-100 font-hud text-xs sm:text-sm font-bold tracking-wider flex items-center justify-center gap-2 shadow-[0_0_22px_rgba(244,63,94,0.5)] transition-all cursor-pointer hover:scale-[1.01]"
                      title="Stop Listening Immediately"
                      aria-label="Stop listening immediately"
                    >
                      <MicOff className="w-5 h-5 text-rose-400 shrink-0" />
                      <span>STOP LISTENING</span>
                    </button>

                    <button
                      onClick={handleTransmitNow}
                      className="w-full py-2 px-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 border border-cyan-300 text-black font-hud text-xs font-bold tracking-wider flex items-center justify-center gap-1.5 shadow-[0_0_15px_#00e5ff] transition-all cursor-pointer hover:scale-[1.01]"
                      title="Send Recognized Voice Command Now"
                      aria-label="Send recognized command now"
                    >
                      <Send className="w-4 h-4 text-black shrink-0" />
                      <span>SEND NOW (SKIP 2.3S PAUSE TIMER)</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Active Action Execution HUD Card (e.g. YouTube Launch) */}
              {activeActionHUD && (
                <div className="w-full max-w-sm mt-2 px-4 animate-in fade-in zoom-in-95 duration-200">
                  <div className="p-3 rounded-xl border bg-slate-950/95 border-cyan-400/50 shadow-[0_0_20px_rgba(0,229,255,0.25)] text-left relative">
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-1.5 text-xs font-hud font-bold text-cyan-300">
                        {activeActionHUD.type === 'OPEN_YOUTUBE' ? (
                          <Youtube className="w-4 h-4 text-red-400 shrink-0" />
                        ) : (
                          <Zap className="w-4 h-4 text-cyan-400 shrink-0" />
                        )}
                        <span className="uppercase tracking-wider">{activeActionHUD.actionName}</span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[8px] font-mono uppercase font-bold flex items-center gap-1 ${
                            activeActionHUD.status === 'executed'
                              ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/50'
                              : activeActionHUD.status === 'ready_to_launch'
                              ? 'bg-red-950/80 text-red-300 border border-red-500/50 animate-pulse'
                              : activeActionHUD.status === 'web_simulation'
                              ? 'bg-amber-950/80 text-amber-300 border border-amber-500/50'
                              : activeActionHUD.status === 'blocked_popup'
                              ? 'bg-amber-950/80 text-amber-300 border border-amber-500/50'
                              : 'bg-blue-950/80 text-blue-300 border border-blue-500/50'
                          }`}
                        >
                          {activeActionHUD.status === 'executed' ? (
                            <>
                              <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" /> Web Dispatched
                            </>
                          ) : activeActionHUD.status === 'ready_to_launch' ? (
                            <>
                              <ExternalLink className="w-2.5 h-2.5 text-red-400" /> Direct Link Ready
                            </>
                          ) : activeActionHUD.status === 'web_simulation' ? (
                            <>
                              <AlertTriangle className="w-2.5 h-2.5 text-amber-400" /> Web Simulation
                            </>
                          ) : activeActionHUD.status === 'blocked_popup' ? (
                            <>
                              <AlertTriangle className="w-2.5 h-2.5 text-amber-400" /> Popup Intercepted
                            </>
                          ) : (
                            <>
                              <ShieldAlert className="w-2.5 h-2.5 text-blue-400" /> Android Native
                            </>
                          )}
                        </span>

                        <button
                          onClick={() => setActiveActionHUD(null)}
                          className="p-1 rounded text-slate-400 hover:text-white cursor-pointer"
                          title="Dismiss action banner"
                          aria-label="Dismiss action banner"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <p className="text-[11px] font-mono text-slate-300 leading-snug mb-2">
                      {activeActionHUD.feedbackText}
                    </p>

                    {/* Direct Native Action Indicator (No Clickable Links Required) */}
                    <div className="flex items-center gap-2 pt-0.5 flex-wrap">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 font-mono text-[10px]">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        <span>Action Dispatched Directly</span>
                      </span>
                      <button
                        onClick={() => setViewMode('chat')}
                        className="text-[10px] font-mono text-cyan-400 hover:underline cursor-pointer"
                      >
                        View in Chat Logs →
                      </button>
                    </div>

                    {/* Native Android Intent Blueprint */}
                    {activeActionHUD.androidIntent && (
                      <div className="mt-2 text-[10px] font-mono text-slate-400/90 bg-slate-900/90 p-1.5 rounded border border-cyan-500/20 space-y-0.5">
                        <div>
                          <span className="text-cyan-400/90 font-semibold">Native Intent:</span>{' '}
                          <code className="text-cyan-200">{activeActionHUD.androidIntent}</code>
                        </div>
                        {activeActionHUD.androidPermissions && activeActionHUD.androidPermissions.length > 0 && (
                          <div>
                            <span className="text-amber-400/90 font-semibold">Manifest:</span>{' '}
                            <code className="text-amber-200">{activeActionHUD.androidPermissions.join(', ')}</code>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Tactical Microphone Control Panel */}
            <div className="flex flex-col items-center justify-center my-2">
              <div className="flex items-center gap-3">
                {/* Audio Cancel Button if speaking */}
                {assistantState === 'speaking' && (
                  <button
                    onClick={handleStopSpeaking}
                    className="p-2.5 rounded-full bg-rose-950/80 border border-rose-500/50 text-rose-300 hover:bg-rose-900 transition-all shadow-[0_0_15px_rgba(244,63,94,0.3)]"
                    title="Silence Audio Output"
                    aria-label="Silence audio output"
                  >
                    <VolumeX className="w-5 h-5" />
                  </button>
                )}

                {/* Primary Illuminated Push-to-Talk Mic Button */}
                <button
                  onClick={handleToggleVoiceInput}
                  className={`w-16 h-16 sm:w-18 sm:h-18 rounded-full flex items-center justify-center border-2 transition-all cursor-pointer relative group ${
                    assistantState === 'listening'
                      ? 'bg-cyan-500 border-white text-black shadow-[0_0_40px_#00e5ff] scale-105'
                      : 'bg-slate-900 border-cyan-500/50 text-cyan-300 hover:border-cyan-400 hover:shadow-[0_0_25px_rgba(0,229,255,0.4)]'
                  }`}
                  aria-label={assistantState === 'listening' ? 'Stop listening' : 'Start listening'}
                >
                  {assistantState === 'listening' && (
                    <div className="absolute -inset-2 rounded-full border border-cyan-400 animate-ping pointer-events-none" />
                  )}
                  {assistantState === 'listening' ? (
                    <MicOff className="w-7 h-7 sm:w-8 sm:h-8" />
                  ) : (
                    <Mic className="w-7 h-7 sm:w-8 sm:h-8 group-hover:scale-110 transition-transform" />
                  )}
                </button>

                {/* Switch to Chat Log Shortcut */}
                <button
                  onClick={() => setViewMode('chat')}
                  className="p-2.5 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-400 hover:border-cyan-400 hover:bg-cyan-950/50 transition-all"
                  title="View Chat Logs"
                  aria-label="View Chat Logs"
                >
                  <MessageSquare className="w-5 h-5" />
                </button>
              </div>

              <span className="text-[10px] font-mono text-cyan-400/80 uppercase tracking-widest mt-2">
                {assistantState === 'listening'
                  ? `RECEPTORS LISTENING (${listeningSecondsLeft}S) • TAP TO STOP`
                  : voiceSettings.continuousConversation
                  ? 'CONTINUOUS MODE ACTIVE • TAP MIC'
                  : 'TAP MICROPHONE TO COMMAND'}
              </span>
            </div>

            {/* Android Device Actions Matrix */}
            <div className="mt-2">
              <DeviceControls
                reminders={reminders}
                onAddReminder={handleAddReminder}
                onDeleteReminder={handleDeleteReminder}
                onLogAction={(msg) => {
                  setMessages((prev) => [
                    ...prev,
                    {
                      id: `act-${Date.now()}`,
                      sender: 'jarvis',
                      text: msg,
                      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                      language,
                      provider: 'device_action',
                    },
                  ]);
                }}
              />
            </div>
          </div>
        ) : (
          /* VIEW 2: FULL INTERACTIVE CHAT LOG MODE */
          <div className="flex-1 flex flex-col space-y-2">
            <div className="flex items-center justify-between px-1">
              <span className="text-[11px] font-mono text-cyan-300 flex items-center gap-1">
                <MessageSquare className="w-3.5 h-3.5" /> Full Neural Conversation History
              </span>
              <button
                onClick={() => setViewMode('orb')}
                className="text-[10px] font-mono text-cyan-400 hover:underline flex items-center gap-1"
              >
                ← Return to Voice Orb HUD
              </button>
            </div>

            {/* Active listening banner with large STOP button inside chat view */}
            {assistantState === 'listening' && (
              <div className="p-2.5 rounded-xl bg-rose-950/90 border-2 border-rose-500 flex items-center justify-between shadow-[0_0_15px_rgba(244,63,94,0.3)] animate-pulse">
                <div className="flex items-center gap-2 text-rose-200 text-xs font-mono">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-400 animate-ping" />
                  <span>Receptors listening ({listeningSecondsLeft}s)...</span>
                </div>
                <button
                  onClick={stopListeningImmediate}
                  className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-hud text-xs font-bold tracking-wider flex items-center gap-1.5 shadow-[0_0_12px_rgba(244,63,94,0.5)] cursor-pointer"
                >
                  <MicOff className="w-3.5 h-3.5" />
                  <span>STOP LISTENING</span>
                </button>
              </div>
            )}

            <div className="flex-1">
              <ChatInterface
                messages={messages}
                onSendMessage={handleSendMessage}
                onSpeakMessage={(msg) => speakResponse(msg.text, msg.language, msg.id)}
                onStopSpeaking={handleStopSpeaking}
                onActionLaunched={handleActionLaunched}
                onOpenCodeTerminal={(sol) => {
                  setActiveCodeSolution(sol);
                  setIsCodeTerminalOpen(true);
                }}
                currentlySpeakingId={currentlySpeakingId}
                language={language}
                disabled={assistantState === 'thinking'}
              />
            </div>
          </div>
        )}
      </main>

      {/* Settings & Configuration Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        voiceSettings={voiceSettings}
        onUpdateVoiceSettings={(updated) =>
          setVoiceSettings((prev) => ({ ...prev, ...updated }))
        }
        language={language}
        onSelectLanguage={handleSelectLanguage}
        systemStatus={systemStatus}
      />

      {/* Android Native Project & Cloud Build Modal */}
      <AndroidBuildModal
        isOpen={isBuildModalOpen}
        onClose={() => setIsBuildModalOpen(false)}
      />

      {/* Gemini API Key Configuration Modal */}
      <ApiKeyModal
        isOpen={isApiKeyModalOpen}
        onClose={() => setIsApiKeyModalOpen(false)}
        initialKey={apiKey}
        onKeySaved={(newKey) => setApiKey(newKey)}
      />

      {/* Permanent Memory Manager Modal */}
      <MemoryModal
        isOpen={isMemoryModalOpen}
        onClose={() => setIsMemoryModalOpen(false)}
        memories={memories}
        onAddMemory={handleAddMemory}
        onDeleteMemory={handleDeleteMemory}
      />

      {/* Coding & PC Troubleshooting Engine Terminal Modal */}
      <CodeTerminalModal
        isOpen={isCodeTerminalOpen}
        onClose={() => setIsCodeTerminalOpen(false)}
        solution={activeCodeSolution}
      />

      {/* Draggable Robotic Floating Arc-Reactor Ball Widget */}
      <FloatingOrbOverlay
        isVisible={isFloatingOrbActive}
        onClose={() => setIsFloatingOrbActive(false)}
        onTriggerListening={() => {
          if (assistantState !== 'listening') {
            handleToggleVoiceInput();
          }
        }}
        isListening={assistantState === 'listening'}
      />

      {/* Coding Master & PC Troubleshooting Studio */}
      <CodingMasterModal
        isOpen={isCodingMasterOpen}
        onClose={() => setIsCodingMasterOpen(false)}
        activeSolution={activeCodeSolution}
        onRequestCode={(prompt: string) => handleSendMessage(prompt)}
        onSpeakExplanation={(text: string) => speakResponse(text, 'hi', `code-tts-${Date.now()}`)}
        isLoading={assistantState === 'thinking'}
      />

      {/* Trade Master Engine Modal */}
      <TradeMasterModal
        isOpen={isTradeMasterOpen}
        onClose={() => setIsTradeMasterOpen(false)}
        initialData={tradeMasterData}
        onSpeakStrategy={(text: string) => speakResponse(text, 'hi', `trade-tts-${Date.now()}`)}
      />
    </AndroidFrame>
  );
}
