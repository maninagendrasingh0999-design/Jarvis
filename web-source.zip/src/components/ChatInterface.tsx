/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect } from 'react';
import {
  Send,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Bot,
  User,
  Sparkles,
  Zap,
  Youtube,
  ExternalLink,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Terminal,
  Code2,
} from 'lucide-react';
import { ChatMessage, ActionExecutionResult, CodeSolution } from '../types';
import { AssistantLanguage } from '../utils/jarvis-core';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  onSpeakMessage: (msg: ChatMessage) => void;
  onStopSpeaking: () => void;
  onActionLaunched?: (action: ActionExecutionResult) => void;
  onOpenCodeTerminal?: (solution: CodeSolution) => void;
  currentlySpeakingId: string | null;
  language: AssistantLanguage;
  disabled?: boolean;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({
  messages,
  onSendMessage,
  onSpeakMessage,
  onStopSpeaking,
  onActionLaunched,
  onOpenCodeTerminal,
  currentlySpeakingId,
  language,
  disabled,
}) => {
  const [inputText, setInputText] = React.useState('');
  const [copiedId, setCopiedId] = React.useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || disabled) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Quick suggestion chips based on active language
  const suggestions = React.useMemo(() => {
    switch (language) {
      case 'hi':
        return [
          'यूट्यूब पर गाने चलाओ',
          'टॉर्च चालू करो',
          '5 मिनट का रिमाइंडर लगाओ',
          'वर्तमान समय क्या है?',
          'जार्विस तुम्हारी स्थिति क्या है?',
        ];
      case 'hinglish':
        return [
          'YouTube pe Iron Man theme bajao',
          'Phone dialer open karo',
          'Torch on karo please',
          '10 min me remind karna',
          'JARVIS system status batao',
        ];
      case 'en':
      default:
        return [
          'Open YouTube and search Stark Tech',
          'Launch phone dialer protocol',
          'Toggle illumination torch',
          'Remind me to recharge in 15 minutes',
          'Run full system diagnostics',
        ];
    }
  }, [language]);

  return (
    <div className="flex flex-col h-full bg-slate-950/70 border border-cyan-500/25 rounded-xl backdrop-blur-md overflow-hidden jarvis-border-glow">
      {/* HUD Header */}
      <div className="px-3.5 py-2 border-b border-cyan-500/20 bg-slate-900/60 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span className="font-hud text-xs font-semibold text-cyan-300 tracking-wider uppercase">
            Communication Log // {language.toUpperCase()}
          </span>
        </div>
        <span className="text-[10px] font-mono text-slate-400">
          {messages.length} Records Transmitted
        </span>
      </div>

      {/* Messages Scroll Area */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-3 space-y-3 min-h-[220px] max-h-[380px] sm:max-h-[460px]"
      >
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-center text-slate-500 font-mono text-xs">
            <Bot className="w-8 h-8 text-cyan-500/40 mb-2 animate-pulse" />
            <p className="text-slate-400 font-tech">JARVIS Neural Interface Ready.</p>
            <p className="text-[11px] text-slate-500 mt-1">Speak into microphone or enter query below.</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isJarvis = msg.sender === 'jarvis';
            const isSpeaking = currentlySpeakingId === msg.id;

            return (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${isJarvis ? 'justify-start' : 'justify-end'}`}
              >
                {isJarvis && (
                  <div className="w-7 h-7 rounded-lg bg-cyan-950/80 border border-cyan-400/50 flex items-center justify-center shrink-0 mt-0.5 shadow-[0_0_10px_rgba(0,229,255,0.3)]">
                    <Bot className="w-4 h-4 text-cyan-300" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-xl p-3 text-xs leading-relaxed transition-all ${
                    isJarvis
                      ? 'bg-slate-900/90 border border-cyan-500/30 text-slate-200 shadow-[0_0_15px_rgba(0,229,255,0.08)]'
                      : 'bg-cyan-950/70 border border-cyan-400/40 text-cyan-100 ml-auto'
                  }`}
                >
                  <div className="flex items-center justify-between gap-3 mb-1 text-[10px] font-mono">
                    <span className={isJarvis ? 'text-cyan-400 font-semibold' : 'text-slate-300'}>
                      {isJarvis ? 'J.A.R.V.I.S.' : 'OPERATOR'}
                    </span>
                    <span className="text-slate-500">{msg.timestamp}</span>
                  </div>

                  <p className="whitespace-pre-wrap select-text font-tech text-xs sm:text-sm">
                    {msg.text}
                  </p>

                  {/* Action Execution Card */}
                  {isJarvis && msg.actionResult && (
                    <div className="mt-2.5 p-2.5 rounded-lg border bg-slate-950/90 border-cyan-500/40 shadow-[0_0_15px_rgba(0,229,255,0.1)] space-y-2">
                      <div className="flex items-center justify-between gap-1 flex-wrap">
                        <div className="flex items-center gap-1.5 text-xs font-hud text-cyan-300">
                          {msg.actionResult.type === 'OPEN_YOUTUBE' ? (
                            <Youtube className="w-4 h-4 text-red-400 shrink-0" />
                          ) : (
                            <Zap className="w-4 h-4 text-cyan-400 shrink-0" />
                          )}
                          <span className="font-bold tracking-wide uppercase">{msg.actionResult.actionName}</span>
                        </div>

                        <span
                          className={`px-1.5 py-0.5 rounded text-[9px] font-mono uppercase font-bold flex items-center gap-1 ${
                            msg.actionResult.status === 'executed'
                              ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/50'
                              : msg.actionResult.status === 'ready_to_launch'
                              ? 'bg-red-950/80 text-red-300 border border-red-500/50 animate-pulse'
                              : msg.actionResult.status === 'web_simulation'
                              ? 'bg-amber-950/80 text-amber-300 border border-amber-500/50'
                              : msg.actionResult.status === 'blocked_popup'
                              ? 'bg-amber-950/80 text-amber-300 border border-amber-500/50'
                              : 'bg-blue-950/80 text-blue-300 border border-blue-500/50'
                          }`}
                        >
                          {msg.actionResult.status === 'executed' ? (
                            <>
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Web Dispatched
                            </>
                          ) : msg.actionResult.status === 'ready_to_launch' ? (
                            <>
                              <ExternalLink className="w-3 h-3 text-red-400" /> Direct Link Ready
                            </>
                          ) : msg.actionResult.status === 'web_simulation' ? (
                            <>
                              <AlertTriangle className="w-3 h-3 text-amber-400" /> Web Simulation
                            </>
                          ) : msg.actionResult.status === 'blocked_popup' ? (
                            <>
                              <AlertTriangle className="w-3 h-3 text-amber-400" /> Popup Intercepted
                            </>
                          ) : (
                            <>
                              <ShieldAlert className="w-3 h-3 text-blue-400" /> Android Native
                            </>
                          )}
                        </span>
                      </div>

                      <p className="text-[11px] font-mono text-slate-300 leading-snug">
                        {msg.actionResult.feedbackText}
                      </p>

                      {/* Direct Native Launch Indicator (No Clickable Links) */}
                      <div className="pt-1 flex items-center gap-2 flex-wrap">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 font-mono text-[10px]">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span>Direct Native Action Dispatched</span>
                        </span>
                        {msg.actionResult.payload?.query && (
                          <span className="text-[10px] font-mono text-slate-400 truncate max-w-[180px]">
                            Query: &quot;{msg.actionResult.payload.query}&quot;
                          </span>
                        )}
                      </div>

                      {/* Native Android Intent and Permission Blueprint */}
                      {msg.actionResult.androidIntent && (
                        <div className="text-[10px] font-mono text-slate-400/90 bg-slate-900/90 p-1.5 rounded border border-cyan-500/20 space-y-0.5">
                          <div>
                            <span className="text-cyan-400/90 font-semibold">Android Intent:</span>{' '}
                            <code className="text-cyan-200">{msg.actionResult.androidIntent}</code>
                          </div>
                          {msg.actionResult.androidPermissions && msg.actionResult.androidPermissions.length > 0 && (
                            <div>
                              <span className="text-amber-400/90 font-semibold">Permissions:</span>{' '}
                              <code className="text-amber-200">{msg.actionResult.androidPermissions.join(', ')}</code>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Coding / PC Troubleshooting Engine Solution Card */}
                  {isJarvis && msg.codeSolution && (
                    <div className="mt-2.5 p-2.5 rounded-lg border bg-slate-950/95 border-cyan-500/50 shadow-[0_0_15px_rgba(0,229,255,0.15)] space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-cyan-300">
                          <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                          <span>{msg.codeSolution.title}</span>
                        </div>
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-mono uppercase bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                          {msg.codeSolution.language}
                        </span>
                      </div>
                      <div className="bg-black/90 p-2 rounded font-mono text-[11px] text-cyan-200 overflow-x-auto max-h-36">
                        <pre><code>{msg.codeSolution.code}</code></pre>
                      </div>
                      <div className="flex justify-between items-center text-[10px] font-mono">
                        <span className="text-slate-400 line-clamp-1">{msg.codeSolution.explanation}</span>
                        <button
                          onClick={() => onOpenCodeTerminal?.(msg.codeSolution!)}
                          className="px-2 py-1 rounded bg-cyan-900/50 hover:bg-cyan-800/60 border border-cyan-500/40 text-cyan-300 flex items-center gap-1 transition-all shrink-0 cursor-pointer"
                        >
                          <Code2 className="w-3 h-3" />
                          <span>Open Terminal</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Badges & Action Bar for Jarvis responses */}
                  {isJarvis && (
                    <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-cyan-500/15 text-[10px] font-mono">
                      <div className="flex items-center gap-1.5 text-cyan-400/80">
                        {msg.provider === 'instant_local_core' ? (
                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded bg-amber-950/80 border border-amber-500/50 text-[9px] text-amber-300">
                            <Zap className="w-2.5 h-2.5" /> Instant Local Core (&lt;5ms)
                          </span>
                        ) : msg.provider?.includes('gemini') ? (
                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded bg-cyan-950 border border-cyan-500/40 text-[9px] text-cyan-300">
                            <Sparkles className="w-2.5 h-2.5" /> Gemini Flash Lite
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded bg-slate-950 border border-slate-700 text-[9px] text-slate-400">
                            <Zap className="w-2.5 h-2.5" /> Offline Neural Core
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        {/* Audio speak button */}
                        <button
                          onClick={() => (isSpeaking ? onStopSpeaking() : onSpeakMessage(msg))}
                          className={`p-1 rounded hover:bg-cyan-900/40 transition-colors ${
                            isSpeaking ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-cyan-300'
                          }`}
                          aria-label={isSpeaking ? 'Stop speech' : 'Read aloud'}
                          title={isSpeaking ? 'Stop speech' : 'Read aloud'}
                        >
                          {isSpeaking ? (
                            <VolumeX className="w-3.5 h-3.5 animate-pulse" />
                          ) : (
                            <Volume2 className="w-3.5 h-3.5" />
                          )}
                        </button>

                        {/* Copy button */}
                        <button
                          onClick={() => handleCopy(msg.id, msg.text)}
                          className="p-1 rounded text-slate-400 hover:text-cyan-300 hover:bg-cyan-900/40 transition-colors"
                          aria-label="Copy message text"
                          title="Copy text"
                        >
                          {copiedId === msg.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {!isJarvis && (
                  <div className="w-7 h-7 rounded-lg bg-blue-950/80 border border-blue-400/50 flex items-center justify-center shrink-0 mt-0.5">
                    <User className="w-4 h-4 text-cyan-300" />
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Suggested Fast Prompts */}
      <div className="px-3 py-1.5 bg-slate-950 border-t border-cyan-500/20 overflow-x-auto flex gap-1.5 text-nowrap scrollbar-none">
        {suggestions.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => onSendMessage(prompt)}
            className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-950 hover:border-cyan-400 transition-colors shrink-0"
          >
            + {prompt}
          </button>
        ))}
      </div>

      {/* Input Message Box */}
      <form
        onSubmit={handleSubmit}
        className="p-2 bg-slate-900/80 border-t border-cyan-500/30 flex items-center gap-2"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          disabled={disabled}
          placeholder={
            language === 'hi'
              ? 'जार्विस से कुछ भी पूछें या कमांड दें...'
              : language === 'hinglish'
              ? 'Ask JARVIS anything in English or Hinglish...'
              : 'Enter voice or text command for JARVIS...'
          }
          className="flex-1 bg-slate-950 border border-cyan-500/30 rounded-lg px-3 py-2 text-xs sm:text-sm text-cyan-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 font-tech"
        />
        <button
          type="submit"
          disabled={!inputText.trim() || disabled}
          className="px-3.5 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-black font-semibold rounded-lg text-xs font-tech tracking-wider flex items-center gap-1 shadow-[0_0_15px_rgba(0,229,255,0.4)] transition-all cursor-pointer"
          aria-label="Send message"
        >
          <Send className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">TRANSMIT</span>
        </button>
      </form>
    </div>
  );
};
