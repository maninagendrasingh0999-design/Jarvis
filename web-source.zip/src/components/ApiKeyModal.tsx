/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Key, ShieldCheck, Check, AlertCircle, Eye, EyeOff, X, Zap } from 'lucide-react';
import { getNativeBridge } from '../utils/action-executor';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onKeySaved: (key: string) => void;
  initialKey?: string;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({
  isOpen,
  onClose,
  onKeySaved,
  initialKey = '',
}) => {
  const [apiKey, setApiKey] = useState<string>(initialKey);
  const [showKey, setShowKey] = useState<boolean>(false);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      const savedKey =
        localStorage.getItem('jarvis_gemini_api_key') ||
        getNativeBridge()?.getApiKey?.() ||
        initialKey ||
        'AIzaSyDNKMF5hhri9fvpU7DSgHyFKB7rdkxKaTI';
      setApiKey(savedKey);
      setIsSaved(false);
      setTestResult(null);
    }
  }, [isOpen, initialKey]);

  if (!isOpen) return null;

  const handleSave = () => {
    const cleanKey = apiKey.trim();
    localStorage.setItem('jarvis_gemini_api_key', cleanKey);
    const bridge = getNativeBridge();
    if (bridge && typeof bridge.saveApiKey === 'function') {
      try {
        bridge.saveApiKey(cleanKey);
      } catch (e) {}
    }
    onKeySaved(cleanKey);
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 1200);
  };

  const handleTestConnection = async () => {
    const cleanKey = apiKey.trim();
    if (!cleanKey) {
      setTestResult({ success: false, message: 'Please enter a Gemini API key first.' });
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: 'Ping test. Reply with one word: Online.',
          apiKey: cleanKey,
          language: 'en',
        }),
      });
      const data = await res.json();
      if (res.ok && data.reply) {
        setTestResult({
          success: true,
          message: `Neural link verified! Model response: "${data.reply}"`,
        });
      } else {
        setTestResult({
          success: false,
          message: data.error || 'Connection failed. Please check the key.',
        });
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err.message || 'Network test failed.',
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-md rounded-2xl border border-cyan-500/40 bg-slate-950/95 p-6 shadow-2xl shadow-cyan-500/20 text-cyan-100">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-cyan-950/40 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <Key className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold tracking-wider text-cyan-300 uppercase font-mono">
              Gemini API Key
            </h3>
            <p className="text-xs text-slate-400">Autonomous Neural Core Authorization</p>
          </div>
        </div>

        <p className="text-xs text-slate-300 mb-4 leading-relaxed">
          Save your personal Google Gemini API key to unlock autonomous device control,
          multi-turn voice conversation, and the super-intelligent coding engine. Stored locally
          in your device secure storage.
        </p>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1.5">
              API Key (AI Studio)
            </label>
            <div className="relative">
              <input
                type={showKey ? 'text' : 'password'}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full px-3.5 py-2.5 pr-10 rounded-xl bg-slate-900/90 border border-cyan-500/30 text-cyan-100 font-mono text-sm placeholder-slate-600 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-cyan-300"
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {testResult && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                testResult.success
                  ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                  : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
              }`}
            >
              {testResult.success ? (
                <Check className="w-4 h-4 mt-0.5 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              )}
              <span className="font-mono">{testResult.message}</span>
            </div>
          )}

          <div className="flex gap-2.5 pt-2">
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isTesting || !apiKey.trim()}
              className="flex-1 py-2.5 px-3 rounded-xl border border-cyan-500/30 bg-cyan-950/30 hover:bg-cyan-900/40 text-cyan-300 text-xs font-mono uppercase tracking-wider font-semibold transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              <Zap className={`w-3.5 h-3.5 ${isTesting ? 'animate-pulse text-amber-400' : ''}`} />
              {isTesting ? 'Testing...' : 'Test Link'}
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-mono uppercase tracking-wider font-semibold shadow-lg shadow-cyan-600/30 transition-all flex items-center justify-center gap-1.5"
            >
              {isSaved ? <Check className="w-3.5 h-3.5" /> : <ShieldCheck className="w-3.5 h-3.5" />}
              {isSaved ? 'Saved Locally!' : 'Save & Activate'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
