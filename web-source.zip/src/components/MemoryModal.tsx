/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Brain, Trash2, Plus, X, Sparkles, Check } from 'lucide-react';
import { MemoryItem } from '../types';
import { getNativeBridge } from '../utils/action-executor';

interface MemoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  memories: MemoryItem[];
  onAddMemory: (key: string, value: string) => void;
  onDeleteMemory: (id: string) => void;
}

export const MemoryModal: React.FC<MemoryModalProps> = ({
  isOpen,
  onClose,
  memories,
  onAddMemory,
  onDeleteMemory,
}) => {
  const [newKey, setNewKey] = useState<string>('');
  const [newValue, setNewValue] = useState<string>('');
  const [showAddForm, setShowAddForm] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSaveMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newValue.trim()) return;
    onAddMemory(newKey.trim(), newValue.trim());
    setNewKey('');
    setNewValue('');
    setShowAddForm(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg max-h-[85vh] flex flex-col rounded-2xl border border-cyan-500/40 bg-slate-950/95 p-6 shadow-2xl shadow-cyan-500/20 text-cyan-100">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-cyan-950/40 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <Brain className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold tracking-wider text-cyan-300 uppercase font-mono">
              JARVIS Permanent Memory
            </h3>
            <p className="text-xs text-slate-400">Persistent Knowledge & User Preferences</p>
          </div>
        </div>

        <p className="text-xs text-slate-300 mb-4 leading-relaxed font-sans">
          JARVIS remembers personal details, preferences, and important facts forever. Stored in
          device storage and injected into the neural prompt on every query.
        </p>

        {/* Add Memory Button / Form */}
        {!showAddForm ? (
          <button
            onClick={() => setShowAddForm(true)}
            className="w-full py-2 px-3 mb-4 rounded-xl border border-dashed border-cyan-500/40 bg-cyan-950/20 hover:bg-cyan-950/40 text-cyan-300 text-xs font-mono font-semibold flex items-center justify-center gap-2 transition-all"
          >
            <Plus className="w-4 h-4" />
            Add New Fact / Memory
          </button>
        ) : (
          <form onSubmit={handleSaveMemory} className="p-3 mb-4 rounded-xl border border-cyan-500/30 bg-slate-900/80 space-y-2">
            <input
              type="text"
              placeholder="Key (e.g. user_name, favorite_car, home_wifi)"
              value={newKey}
              onChange={(e) => setNewKey(e.target.value)}
              className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-cyan-500/30 text-cyan-100 text-xs font-mono placeholder-slate-600 focus:outline-none focus:border-cyan-400"
            />
            <textarea
              placeholder="Fact / Memory to remember forever..."
              value={newValue}
              onChange={(e) => setNewValue(e.target.value)}
              rows={2}
              className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-cyan-500/30 text-cyan-100 text-xs font-mono placeholder-slate-600 focus:outline-none focus:border-cyan-400"
            />
            <div className="flex gap-2 justify-end">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-2.5 py-1 text-xs text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-3 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-mono font-semibold"
              >
                Save Fact
              </button>
            </div>
          </form>
        )}

        {/* Memory List */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {memories.length === 0 ? (
            <div className="p-6 text-center text-slate-500 text-xs font-mono">
              No memories stored yet. You can tell JARVIS: "Remember that my name is Rahul" or add one above.
            </div>
          ) : (
            memories.map((m) => (
              <div
                key={m.id}
                className="group flex items-start justify-between p-3 rounded-xl border border-cyan-500/20 bg-slate-900/60 hover:border-cyan-500/40 transition-all"
              >
                <div className="flex-1 min-w-0 pr-3">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <Sparkles className="w-3 h-3 text-cyan-400 shrink-0" />
                    <span className="text-xs font-mono font-bold text-cyan-300 uppercase">
                      {m.key}
                    </span>
                  </div>
                  <p className="text-xs text-slate-200 font-sans break-words">{m.value}</p>
                </div>
                <button
                  onClick={() => onDeleteMemory(m.id)}
                  className="opacity-60 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-400 transition-colors"
                  title="Forget memory"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
