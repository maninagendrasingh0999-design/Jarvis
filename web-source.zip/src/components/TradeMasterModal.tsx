/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { TrendingUp, TrendingDown, DollarSign, Percent, Calculator, Volume2, X, ShieldAlert, CheckCircle2, ArrowRight } from 'lucide-react';
import { TradeMasterData } from '../types';

interface TradeMasterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSpeakStrategy: (text: string) => void;
  initialData?: TradeMasterData | null;
}

export const TradeMasterModal: React.FC<TradeMasterModalProps> = ({
  isOpen,
  onClose,
  onSpeakStrategy,
  initialData,
}) => {
  const [market, setMarket] = useState<'crypto' | 'stocks'>('crypto');
  const [symbol, setSymbol] = useState<string>('BTC/USDT');
  const [tradeType, setTradeType] = useState<'long' | 'short'>('long');

  // Input states
  const [capital, setCapital] = useState<number>(100000); // 100k
  const [riskPercent, setRiskPercent] = useState<number>(2); // 2%
  const [entryPrice, setEntryPrice] = useState<number>(68500);
  const [stopLossPrice, setStopLossPrice] = useState<number>(67000);
  const [targetPrice, setTargetPrice] = useState<number>(72500);

  // Sync initialData if provided from voice/AI query
  React.useEffect(() => {
    if (initialData) {
      if (initialData.market) setMarket(initialData.market);
      if (initialData.symbol) setSymbol(initialData.symbol);
      if (initialData.tradeType) setTradeType(initialData.tradeType);
      if (initialData.entryPrice) setEntryPrice(initialData.entryPrice);
      if (initialData.stopLossPrice) setStopLossPrice(initialData.stopLossPrice);
      if (initialData.targetPrice) setTargetPrice(initialData.targetPrice);
      if (initialData.capital) setCapital(initialData.capital);
      if (initialData.riskPercent) setRiskPercent(initialData.riskPercent);
    }
  }, [initialData]);

  // Switch symbol presets
  const cryptoPresets = [
    { sym: 'BTC/USDT', entry: 68500, sl: 67200, tgt: 72000 },
    { sym: 'ETH/USDT', entry: 3500, sl: 3420, tgt: 3750 },
    { sym: 'SOL/USDT', entry: 185, sl: 178, tgt: 205 },
  ];

  const stockPresets = [
    { sym: 'NIFTY 50', entry: 24500, sl: 24350, tgt: 24900 },
    { sym: 'BANKNIFTY', entry: 51200, sl: 50800, tgt: 52400 },
    { sym: 'RELIANCE', entry: 2950, sl: 2910, tgt: 3080 },
    { sym: 'NVDA', entry: 135, sl: 129, tgt: 152 },
  ];

  const handleSelectPreset = (p: { sym: string; entry: number; sl: number; tgt: number }) => {
    setSymbol(p.sym);
    setEntryPrice(p.entry);
    setStopLossPrice(p.sl);
    setTargetPrice(p.tgt);
  };

  // Math calculations
  const calc = useMemo(() => {
    const riskDiff = Math.abs(entryPrice - stopLossPrice);
    const rewardDiff = Math.abs(targetPrice - entryPrice);

    const rrRatio = riskDiff > 0 ? (rewardDiff / riskDiff) : 0;
    const maxRiskAmount = (capital * riskPercent) / 100;
    const positionSizeQty = riskDiff > 0 ? (maxRiskAmount / riskDiff) : 0;
    const totalPositionValue = positionSizeQty * entryPrice;
    const projectedProfit = positionSizeQty * rewardDiff;

    return {
      riskRewardRatio: parseFloat(rrRatio.toFixed(2)),
      maxRiskAmount: Math.round(maxRiskAmount),
      projectedProfit: Math.round(projectedProfit),
      positionSizeQty: parseFloat(positionSizeQty.toFixed(4)),
      totalPositionValue: Math.round(totalPositionValue),
      isRiskValid: (tradeType === 'long' ? stopLossPrice < entryPrice : stopLossPrice > entryPrice),
      isTargetValid: (tradeType === 'long' ? targetPrice > entryPrice : targetPrice < entryPrice),
    };
  }, [capital, riskPercent, entryPrice, stopLossPrice, targetPrice, tradeType]);

  // Dynamic Hinglish Strategy generator
  const hinglishAdvice = useMemo(() => {
    const curSymbol = symbol;
    const rr = calc.riskRewardRatio;
    const dir = tradeType === 'long' ? 'Buy (Long)' : 'Sell (Short)';

    if (!calc.isRiskValid || !calc.isTargetValid) {
      return `Sir, Stop-Loss ya Target price invalid hai. ${dir} trade me Stop-Loss entry ke opposite side hona chahiye.`;
    }

    if (rr >= 2.5) {
      return `Sir, ${curSymbol} me ${dir} trade setup ka Risk:Reward ratio 1:${rr} bohot solid hai! Max risk ₹${calc.maxRiskAmount} ke hisab se ${calc.positionSizeQty} quantity lein. Strict Stop-Loss level ${stopLossPrice} follow karein.`;
    } else if (rr >= 1.5) {
      return `Sir, ${curSymbol} setup standard 1:${rr} Risk:Reward ratio de raha hai. Half quantity book karne ka plan rakhein aur trailing Stop-Loss lagayein.`;
    } else {
      return `Sir, yeh setup 1:${rr} Risk:Reward ratio par high-risk lag raha hai. Minimum 1:2 ratio aane tak wait karein ya Target adjust karein.`;
    }
  }, [calc, symbol, tradeType, stopLossPrice]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl border border-cyan-500/40 bg-slate-950/98 shadow-2xl shadow-cyan-500/25 text-cyan-100 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-cyan-500/30 bg-slate-900/90 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <TrendingUp className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold tracking-wider text-cyan-300 font-mono uppercase">
                JARVIS TRADE MASTER ENGINE
              </h3>
              <p className="text-[11px] text-slate-400 font-sans">
                Live Risk:Reward, Position Sizing & Hinglish AI Strategy
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-cyan-950/50 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Market & Trade Direction Toggles */}
        <div className="p-4 bg-slate-900/40 border-b border-cyan-500/20 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <div className="flex bg-slate-950 border border-cyan-500/30 rounded-xl p-0.5 text-xs font-mono">
              <button
                type="button"
                onClick={() => {
                  setMarket('crypto');
                  handleSelectPreset(cryptoPresets[0]);
                }}
                className={`px-3 py-1 rounded-lg transition-all ${
                  market === 'crypto'
                    ? 'bg-cyan-500 text-black font-bold shadow-[0_0_8px_#00e5ff]'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Crypto
              </button>
              <button
                type="button"
                onClick={() => {
                  setMarket('stocks');
                  handleSelectPreset(stockPresets[0]);
                }}
                className={`px-3 py-1 rounded-lg transition-all ${
                  market === 'stocks'
                    ? 'bg-cyan-500 text-black font-bold shadow-[0_0_8px_#00e5ff]'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Stocks
              </button>
            </div>

            <div className="flex bg-slate-950 border border-cyan-500/30 rounded-xl p-0.5 text-xs font-mono">
              <button
                type="button"
                onClick={() => setTradeType('long')}
                className={`px-3 py-1 rounded-lg flex items-center gap-1 transition-all ${
                  tradeType === 'long'
                    ? 'bg-emerald-500 text-black font-bold shadow-[0_0_8px_#10b981]'
                    : 'text-slate-400 hover:text-emerald-300'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Long (Buy)</span>
              </button>
              <button
                type="button"
                onClick={() => setTradeType('short')}
                className={`px-3 py-1 rounded-lg flex items-center gap-1 transition-all ${
                  tradeType === 'short'
                    ? 'bg-rose-500 text-white font-bold shadow-[0_0_8px_#f43f5e]'
                    : 'text-slate-400 hover:text-rose-300'
                }`}
              >
                <TrendingDown className="w-3.5 h-3.5" />
                <span>Short (Sell)</span>
              </button>
            </div>
          </div>

          {/* Quick Presets */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-nowrap">
            {(market === 'crypto' ? cryptoPresets : stockPresets).map((p) => (
              <button
                key={p.sym}
                onClick={() => handleSelectPreset(p)}
                className={`px-2.5 py-1 rounded-lg border text-[10px] font-mono transition-all ${
                  symbol === p.sym
                    ? 'border-cyan-400 bg-cyan-950 text-cyan-300 shadow-[0_0_8px_rgba(0,229,255,0.3)]'
                    : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                {p.sym}
              </button>
            ))}
          </div>
        </div>

        {/* Dashboard Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Key Metric HUD Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 rounded-2xl bg-slate-900/80 border border-cyan-500/25">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Risk : Reward</span>
              <div className="text-xl font-bold font-mono text-cyan-300 mt-0.5">
                1 : {calc.riskRewardRatio}
              </div>
              <span className={`text-[10px] font-mono ${calc.riskRewardRatio >= 2 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {calc.riskRewardRatio >= 2 ? 'Optimal Ratio' : 'High Risk Ratio'}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/80 border border-rose-500/25">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Max Loss (SL)</span>
              <div className="text-xl font-bold font-mono text-rose-400 mt-0.5">
                ₹{calc.maxRiskAmount.toLocaleString()}
              </div>
              <span className="text-[10px] font-mono text-slate-400">
                {riskPercent}% of Capital
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/80 border border-emerald-500/25">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Est. Profit (Target)</span>
              <div className="text-xl font-bold font-mono text-emerald-400 mt-0.5">
                ₹{calc.projectedProfit.toLocaleString()}
              </div>
              <span className="text-[10px] font-mono text-emerald-400">
                +{((calc.projectedProfit / capital) * 100).toFixed(1)}% Return
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/80 border border-cyan-500/25">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Position Size</span>
              <div className="text-xl font-bold font-mono text-cyan-300 mt-0.5 truncate">
                {calc.positionSizeQty}
              </div>
              <span className="text-[10px] font-mono text-slate-400 truncate block">
                Val: ₹{calc.totalPositionValue.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Calculator Input Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-900/60 border border-cyan-500/20">
            <div>
              <label className="block text-[11px] font-mono text-cyan-400 uppercase tracking-wider mb-1">
                Account Capital (₹ / $)
              </label>
              <input
                type="number"
                value={capital}
                onChange={(e) => setCapital(Math.max(1, Number(e.target.value)))}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-cyan-500/30 text-cyan-100 font-mono text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono text-cyan-400 uppercase tracking-wider mb-1">
                Risk Per Trade (%)
              </label>
              <input
                type="number"
                step="0.5"
                min="0.5"
                max="20"
                value={riskPercent}
                onChange={(e) => setRiskPercent(Math.max(0.1, Number(e.target.value)))}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-cyan-500/30 text-cyan-100 font-mono text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono text-cyan-400 uppercase tracking-wider mb-1">
                Entry Price ({symbol})
              </label>
              <input
                type="number"
                step="any"
                value={entryPrice}
                onChange={(e) => setEntryPrice(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-cyan-500/30 text-cyan-100 font-mono text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono text-rose-400 uppercase tracking-wider mb-1">
                Stop-Loss Price
              </label>
              <input
                type="number"
                step="any"
                value={stopLossPrice}
                onChange={(e) => setStopLossPrice(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-rose-500/30 text-rose-200 font-mono text-xs focus:outline-none focus:border-rose-400"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-[11px] font-mono text-emerald-400 uppercase tracking-wider mb-1">
                Target / Take-Profit Price
              </label>
              <input
                type="number"
                step="any"
                value={targetPrice}
                onChange={(e) => setTargetPrice(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-emerald-500/30 text-emerald-200 font-mono text-xs focus:outline-none focus:border-emerald-400"
              />
            </div>
          </div>

          {/* AI Hinglish Strategy Box */}
          <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 flex items-start justify-between gap-3 shadow-[0_0_15px_rgba(0,229,255,0.1)]">
            <div className="flex-1">
              <div className="flex items-center gap-2 text-cyan-300 font-mono font-bold text-xs uppercase mb-1">
                <Calculator className="w-4 h-4 text-cyan-400" />
                <span>JARVIS Tactical Strategy (Hinglish)</span>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed font-sans">
                {hinglishAdvice}
              </p>
            </div>

            <button
              onClick={() => onSpeakStrategy(hinglishAdvice)}
              className="p-2.5 rounded-xl bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 transition-all shrink-0 cursor-pointer shadow-md"
              title="Vocalize trading strategy via JARVIS Voice"
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
