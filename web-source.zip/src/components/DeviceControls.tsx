/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Youtube,
  PhoneCall,
  Flashlight,
  Bell,
  Settings,
  ExternalLink,
  ShieldAlert,
  Smartphone,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Clock,
  Plus,
  Trash2,
} from 'lucide-react';
import { toggleWebTorch } from '../utils/audio';
import { ReminderItem } from '../types';

interface DeviceControlsProps {
  reminders: ReminderItem[];
  onAddReminder: (text: string, minutes: number) => void;
  onDeleteReminder: (id: string) => void;
  onLogAction?: (text: string) => void;
}

export const DeviceControls: React.FC<DeviceControlsProps> = ({
  reminders,
  onAddReminder,
  onDeleteReminder,
  onLogAction,
}) => {
  const [activeModal, setActiveModal] = useState<
    'none' | 'youtube' | 'dialer' | 'flashlight' | 'reminders' | 'settings'
  >('none');

  // Flashlight state
  const [torchActive, setTorchActive] = useState<boolean>(false);
  const [torchStatusMsg, setTorchStatusMsg] = useState<string>('');
  const [torchLoading, setTorchLoading] = useState<boolean>(false);

  // Dialer input
  const [dialNumber, setDialNumber] = useState<string>('');

  // YouTube query
  const [ytQuery, setYtQuery] = useState<string>('');

  // Reminder form
  const [newReminderText, setNewReminderText] = useState<string>('');
  const [newReminderMins, setNewReminderMins] = useState<number>(5);

  const handleToggleTorch = async () => {
    setTorchLoading(true);
    const nextState = !torchActive;
    const res = await toggleWebTorch(nextState);
    setTorchActive(res.state);
    setTorchStatusMsg(res.message);
    setTorchLoading(false);
    if (onLogAction) {
      onLogAction(`Torch command executed: ${res.message}`);
    }
  };

  const handleOpenDialer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dialNumber.trim()) return;
    const cleanNum = dialNumber.trim();
    if (onLogAction) {
      onLogAction(`Phone dialer initiated for ${cleanNum}`);
    }
    // Launch standard tel: URI which mobile browsers handle
    window.location.href = `tel:${encodeURIComponent(cleanNum)}`;
    setActiveModal('none');
  };

  const computedYtUrl = ytQuery.trim()
    ? `https://www.youtube.com/results?search_query=${encodeURIComponent(ytQuery.trim())}`
    : 'https://www.youtube.com/';

  const handleOpenYoutubeDirect = () => {
    const query = ytQuery.trim();
    if (onLogAction) {
      onLogAction(`YouTube launched via direct link for "${query || 'Homepage'}"`);
    }
    setActiveModal('none');
  };

  const handleCreateReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReminderText.trim()) return;
    onAddReminder(newReminderText.trim(), Number(newReminderMins));
    setNewReminderText('');
    if (onLogAction) {
      onLogAction(`Reminder created: "${newReminderText}" in ${newReminderMins} mins`);
    }
  };

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-hud text-xs tracking-wider text-cyan-400 uppercase flex items-center gap-1.5">
          <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
          Android Device Operations Matrix
        </h3>
        <span className="text-[10px] font-mono text-slate-400 bg-slate-900/80 px-2 py-0.5 rounded border border-cyan-500/20">
          Native vs Web Capability
        </span>
      </div>

      {/* Grid of 5 Device Action Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {/* 1. YouTube */}
        <button
          onClick={() => setActiveModal('youtube')}
          className="flex flex-col items-center justify-center p-2.5 rounded-lg bg-slate-950/80 border border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-950/30 transition-all group text-left relative overflow-hidden"
          aria-label="Open YouTube action"
        >
          <div className="w-8 h-8 rounded-full bg-red-950/60 border border-red-500/40 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
            <Youtube className="w-4 h-4 text-red-400" />
          </div>
          <span className="font-tech text-xs font-semibold text-slate-200">YouTube</span>
          <span className="text-[9px] font-mono text-emerald-400 flex items-center gap-0.5 mt-0.5">
            <CheckCircle2 className="w-2.5 h-2.5" /> Web & Native
          </span>
        </button>

        {/* 2. Phone Dialer */}
        <button
          onClick={() => setActiveModal('dialer')}
          className="flex flex-col items-center justify-center p-2.5 rounded-lg bg-slate-950/80 border border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-950/30 transition-all group text-left relative overflow-hidden"
          aria-label="Open Phone Dialer action"
        >
          <div className="w-8 h-8 rounded-full bg-blue-950/60 border border-blue-500/40 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
            <PhoneCall className="w-4 h-4 text-cyan-400" />
          </div>
          <span className="font-tech text-xs font-semibold text-slate-200">Phone Dialer</span>
          <span className="text-[9px] font-mono text-amber-400 flex items-center gap-0.5 mt-0.5">
            <ShieldAlert className="w-2.5 h-2.5" /> tel: / Native
          </span>
        </button>

        {/* 3. Flashlight */}
        <button
          onClick={() => setActiveModal('flashlight')}
          className="flex flex-col items-center justify-center p-2.5 rounded-lg bg-slate-950/80 border border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-950/30 transition-all group text-left relative overflow-hidden"
          aria-label="Flashlight control action"
        >
          <div
            className={`w-8 h-8 rounded-full ${
              torchActive
                ? 'bg-amber-400/30 border-amber-300 shadow-[0_0_15px_#f59e0b]'
                : 'bg-slate-900 border-cyan-500/40'
            } border flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform`}
          >
            <Flashlight className={`w-4 h-4 ${torchActive ? 'text-amber-300' : 'text-cyan-400'}`} />
          </div>
          <span className="font-tech text-xs font-semibold text-slate-200">Flashlight</span>
          <span
            className={`text-[9px] font-mono flex items-center gap-0.5 mt-0.5 ${
              torchActive ? 'text-amber-300 font-bold' : 'text-slate-400'
            }`}
          >
            {torchActive ? 'ACTIVE' : 'Camera Torch'}
          </span>
        </button>

        {/* 4. Reminders */}
        <button
          onClick={() => setActiveModal('reminders')}
          className="flex flex-col items-center justify-center p-2.5 rounded-lg bg-slate-950/80 border border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-950/30 transition-all group text-left relative overflow-hidden"
          aria-label="Reminders and Alarms action"
        >
          <div className="w-8 h-8 rounded-full bg-purple-950/60 border border-purple-500/40 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
            <Bell className="w-4 h-4 text-purple-400" />
          </div>
          <span className="font-tech text-xs font-semibold text-slate-200">Reminders</span>
          <span className="text-[9px] font-mono text-purple-400 flex items-center gap-0.5 mt-0.5">
            <Clock className="w-2.5 h-2.5" /> {reminders.filter((r) => !r.completed).length} Active
          </span>
        </button>

        {/* 5. Phone Settings */}
        <button
          onClick={() => setActiveModal('settings')}
          className="flex flex-col items-center justify-center p-2.5 rounded-lg bg-slate-950/80 border border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-950/30 transition-all group text-left relative overflow-hidden col-span-2 sm:col-span-1"
          aria-label="Phone Settings action"
        >
          <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-600 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
            <Settings className="w-4 h-4 text-slate-300" />
          </div>
          <span className="font-tech text-xs font-semibold text-slate-200">Phone Settings</span>
          <span className="text-[9px] font-mono text-amber-400 flex items-center gap-0.5 mt-0.5">
            <ShieldAlert className="w-2.5 h-2.5" /> Native Intent
          </span>
        </button>
      </div>

      {/* --- Action Modals --- */}

      {/* 1. YouTube Modal */}
      {activeModal === 'youtube' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-cyan-500/50 rounded-xl max-w-md w-full p-5 jarvis-glow relative">
            <div className="flex items-center justify-between pb-3 border-b border-cyan-500/20">
              <div className="flex items-center gap-2">
                <Youtube className="w-5 h-5 text-red-500" />
                <h4 className="font-hud text-sm font-semibold text-white tracking-wide">
                  YouTube Dispatch Protocol
                </h4>
              </div>
              <button
                onClick={() => setActiveModal('none')}
                className="text-slate-400 hover:text-white p-1"
                aria-label="Close YouTube modal"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  Query or Video Name (Optional):
                </label>
                <input
                  type="text"
                  value={ytQuery}
                  onChange={(e) => setYtQuery(e.target.value)}
                  placeholder="e.g. Iron Man theme music, Tech news..."
                  className="w-full bg-slate-900 border border-cyan-500/30 rounded px-3 py-2 text-sm text-cyan-200 focus:outline-none focus:border-cyan-400"
                />
              </div>

              {/* Native Android vs Web Explanation */}
              <div className="bg-slate-900/90 rounded p-2.5 border border-cyan-500/20 text-[11px] font-mono text-slate-400 space-y-1">
                <p className="text-cyan-300 font-semibold flex items-center gap-1">
                  <Smartphone className="w-3.5 h-3.5" /> Android Integration Blueprint:
                </p>
                <p>• <span className="text-white">Web Preview:</span> Opens official YouTube interface with your search parameter in a new tab.</p>
                <p>• <span className="text-white">Native Android APK:</span> Launches YouTube Android App via <code className="text-cyan-400">Intent(ACTION_VIEW, Uri.parse("vnd.youtube:..."))</code> with fall back to browser.</p>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('none')}
                  className="px-3 py-1.5 text-xs font-mono text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <a
                  href={computedYtUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={handleOpenYoutubeDirect}
                  className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded font-tech text-xs tracking-wider flex items-center gap-1.5 shadow-[0_0_15px_rgba(239,68,68,0.4)] cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" /> Open YouTube Now
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Phone Dialer Modal */}
      {activeModal === 'dialer' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-cyan-500/50 rounded-xl max-w-md w-full p-5 jarvis-glow relative">
            <div className="flex items-center justify-between pb-3 border-b border-cyan-500/20">
              <div className="flex items-center gap-2">
                <PhoneCall className="w-5 h-5 text-cyan-400" />
                <h4 className="font-hud text-sm font-semibold text-white tracking-wide">
                  Phone Dialer Matrix
                </h4>
              </div>
              <button
                onClick={() => setActiveModal('none')}
                className="text-slate-400 hover:text-white p-1"
                aria-label="Close Dialer modal"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleOpenDialer} className="mt-4 space-y-3">
              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  Telephone Number:
                </label>
                <input
                  type="tel"
                  required
                  value={dialNumber}
                  onChange={(e) => setDialNumber(e.target.value)}
                  placeholder="+1 (800) 555-0199 or 9876543210"
                  className="w-full bg-slate-900 border border-cyan-500/30 rounded px-3 py-2 text-sm text-cyan-200 focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>

              {/* Native Android vs Web Explanation */}
              <div className="bg-slate-900/90 rounded p-2.5 border border-amber-500/30 text-[11px] font-mono text-slate-400 space-y-1">
                <p className="text-amber-300 font-semibold flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5" /> Android Permission Notice:
                </p>
                <p>• <span className="text-white">Web Protocol:</span> Emits standard <code className="text-cyan-400">tel:</code> URI scheme. The phone or OS prompts you to confirm before placing the call.</p>
                <p>• <span className="text-white">Native Android APK:</span> Uses <code className="text-cyan-400">Intent(Intent.ACTION_DIAL)</code> for user prompt, or <code className="text-cyan-400">ACTION_CALL</code> requiring <code className="text-amber-400">android.permission.CALL_PHONE</code> granted in AndroidManifest.xml.</p>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('none')}
                  className="px-3 py-1.5 text-xs font-mono text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-tech text-xs tracking-wider flex items-center gap-1.5 shadow-[0_0_15px_rgba(0,229,255,0.4)]"
                >
                  <PhoneCall className="w-3.5 h-3.5" /> Launch Dialer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. Flashlight Modal */}
      {activeModal === 'flashlight' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-cyan-500/50 rounded-xl max-w-md w-full p-5 jarvis-glow relative">
            <div className="flex items-center justify-between pb-3 border-b border-cyan-500/20">
              <div className="flex items-center gap-2">
                <Flashlight className={`w-5 h-5 ${torchActive ? 'text-amber-400' : 'text-cyan-400'}`} />
                <h4 className="font-hud text-sm font-semibold text-white tracking-wide">
                  Illumination Protocol (Flashlight)
                </h4>
              </div>
              <button
                onClick={() => setActiveModal('none')}
                className="text-slate-400 hover:text-white p-1"
                aria-label="Close Flashlight modal"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4">
              <div className="flex flex-col items-center justify-center py-4 bg-slate-900/50 rounded-xl border border-cyan-500/20">
                <button
                  onClick={handleToggleTorch}
                  disabled={torchLoading}
                  className={`w-20 h-20 rounded-full border-2 flex items-center justify-center transition-all ${
                    torchActive
                      ? 'bg-amber-400/20 border-amber-400 text-amber-300 shadow-[0_0_30px_rgba(245,158,11,0.6)]'
                      : 'bg-slate-800/80 border-slate-600 text-slate-400 hover:border-cyan-400 hover:text-cyan-300'
                  }`}
                  aria-label="Toggle Flashlight Torch"
                >
                  <Flashlight className="w-9 h-9" />
                </button>
                <span className="font-tech text-sm font-bold tracking-widest mt-2 text-slate-200">
                  {torchLoading ? 'INITIALIZING...' : torchActive ? 'TORCH ACTIVE' : 'TORCH STANDBY'}
                </span>
                {torchStatusMsg && (
                  <p className="text-xs font-mono text-cyan-300 text-center px-4 mt-1">
                    {torchStatusMsg}
                  </p>
                )}
              </div>

              {/* Native Android Hardware Explanation */}
              <div className="bg-slate-900/90 rounded p-2.5 border border-cyan-500/20 text-[11px] font-mono text-slate-400 space-y-1">
                <p className="text-cyan-300 font-semibold flex items-center gap-1">
                  <HelpCircle className="w-3.5 h-3.5" /> Hardware & Android Permissions:
                </p>
                <p>• <span className="text-white">Web API:</span> Uses <code className="text-cyan-400">navigator.mediaDevices.getUserMedia</code> with camera torch constraint. Requires camera consent from user. Supported on Android Chrome; unavailable on PCs without phone camera flash.</p>
                <p>• <span className="text-white">Android Native APK:</span> Directly calls Android <code className="text-cyan-400">CameraManager.setTorchMode(cameraId, true)</code> with <code className="text-cyan-400">android.permission.CAMERA</code> and <code className="text-cyan-400">android.permission.FLASHLIGHT</code>.</p>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('none')}
                  className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded font-tech text-xs tracking-wider"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Reminders Modal */}
      {activeModal === 'reminders' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-cyan-500/50 rounded-xl max-w-md w-full p-5 jarvis-glow relative">
            <div className="flex items-center justify-between pb-3 border-b border-cyan-500/20">
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-purple-400" />
                <h4 className="font-hud text-sm font-semibold text-white tracking-wide">
                  Chronological Alerts & Reminders
                </h4>
              </div>
              <button
                onClick={() => setActiveModal('none')}
                className="text-slate-400 hover:text-white p-1"
                aria-label="Close Reminders modal"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateReminder} className="mt-4 space-y-3">
              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <label className="block text-[11px] font-mono text-slate-300 mb-1">
                    Task / Alert Description:
                  </label>
                  <input
                    type="text"
                    required
                    value={newReminderText}
                    onChange={(e) => setNewReminderText(e.target.value)}
                    placeholder="e.g. Call Stark Tower, Drink Water"
                    className="w-full bg-slate-900 border border-cyan-500/30 rounded px-2.5 py-1.5 text-xs text-cyan-200 focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-slate-300 mb-1">
                    Minutes:
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="1440"
                    value={newReminderMins}
                    onChange={(e) => setNewReminderMins(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full bg-slate-900 border border-cyan-500/30 rounded px-2.5 py-1.5 text-xs text-cyan-200 focus:outline-none focus:border-cyan-400 font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded font-tech text-xs tracking-wider flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(168,85,247,0.4)]"
              >
                <Plus className="w-3.5 h-3.5" /> Schedule Protocol Alert
              </button>
            </form>

            {/* Active Reminders List */}
            <div className="mt-4">
              <h5 className="text-[11px] font-mono text-cyan-400 uppercase tracking-wider mb-1.5">
                Active Protocol Reminders ({reminders.length}):
              </h5>
              <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
                {reminders.length === 0 ? (
                  <p className="text-xs font-mono text-slate-500 italic py-2 text-center">
                    No active reminders scheduled.
                  </p>
                ) : (
                  reminders.map((rem) => {
                    const remainingMs = Math.max(0, rem.dueTime - Date.now());
                    const remainingMins = Math.ceil(remainingMs / 60000);
                    return (
                      <div
                        key={rem.id}
                        className="flex items-center justify-between p-2 rounded bg-slate-900/80 border border-cyan-500/20 text-xs"
                      >
                        <div>
                          <p className="font-semibold text-slate-200">{rem.text}</p>
                          <p className="text-[10px] font-mono text-slate-400">
                            Due in ~{remainingMins} min ({new Date(rem.dueTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})
                          </p>
                        </div>
                        <button
                          onClick={() => onDeleteReminder(rem.id)}
                          className="text-slate-400 hover:text-rose-400 p-1"
                          title="Delete reminder"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Android Alarm & Background Service Blueprint */}
            <div className="mt-3 bg-slate-900/90 rounded p-2.5 border border-purple-500/20 text-[10px] font-mono text-slate-400 space-y-0.5">
              <p className="text-purple-300 font-semibold">Android Wake Service Architecture:</p>
              <p>• In native Android APK, reminders use <code className="text-purple-400">AlarmManager.setExactAndAllowWhileIdle()</code> or Android WorkManager with <code className="text-purple-400">WAKE_LOCK</code> so notifications ring even when device screen is turned off.</p>
            </div>
          </div>
        </div>
      )}

      {/* 5. Phone Settings Modal */}
      {activeModal === 'settings' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-cyan-500/50 rounded-xl max-w-md w-full p-5 jarvis-glow relative">
            <div className="flex items-center justify-between pb-3 border-b border-cyan-500/20">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-slate-300" />
                <h4 className="font-hud text-sm font-semibold text-white tracking-wide">
                  Android Phone Settings Intent Portal
                </h4>
              </div>
              <button
                onClick={() => setActiveModal('none')}
                className="text-slate-400 hover:text-white p-1"
                aria-label="Close Settings modal"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs font-mono">
              <div className="p-3 rounded bg-amber-950/40 border border-amber-500/40 text-amber-200 text-[11px] leading-relaxed">
                <p className="font-bold flex items-center gap-1 text-amber-400 mb-1">
                  <ShieldAlert className="w-4 h-4" /> Native OS Security Boundary:
                </p>
                Browsers run inside a secure sandbox and are strictly prohibited by the Android OS from modifying device settings (such as Wi-Fi toggles, Bluetooth, screen timeout, or airplane mode) directly through web pages.
              </div>

              <div className="space-y-2">
                <h5 className="text-[11px] font-semibold text-cyan-300 uppercase">
                  Native Android Intent Implementation:
                </h5>

                <div className="p-2 rounded bg-slate-900 border border-cyan-500/20 text-[11px] space-y-1">
                  <p className="text-slate-300 font-semibold">1. Open Device Settings:</p>
                  <code className="text-cyan-400 block bg-black/50 p-1.5 rounded">
                    val intent = Intent(Settings.ACTION_SETTINGS)<br />
                    context.startActivity(intent)
                  </code>
                </div>

                <div className="p-2 rounded bg-slate-900 border border-cyan-500/20 text-[11px] space-y-1">
                  <p className="text-slate-300 font-semibold">2. Open Wireless & Wi-Fi Settings:</p>
                  <code className="text-cyan-400 block bg-black/50 p-1.5 rounded">
                    val intent = Intent(Settings.ACTION_WIFI_SETTINGS)<br />
                    context.startActivity(intent)
                  </code>
                </div>

                <div className="p-2 rounded bg-slate-900 border border-cyan-500/20 text-[11px] space-y-1">
                  <p className="text-slate-300 font-semibold">3. Required Manifest Permissions:</p>
                  <code className="text-amber-300 block bg-black/50 p-1.5 rounded">
                    &lt;uses-permission android:name="android.permission.WRITE_SETTINGS" /&gt;<br />
                    &lt;uses-permission android:name="android.permission.CHANGE_WIFI_STATE" /&gt;
                  </code>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('none')}
                  className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-tech text-xs tracking-wider"
                >
                  Acknowledge Architecture
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
