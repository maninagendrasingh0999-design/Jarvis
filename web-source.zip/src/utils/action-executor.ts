/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CommandIntent } from './jarvis-core';
import { ActionExecutionResult, StructuredAction } from '../types';

/**
 * Triggers MacroDroid Local HTTP Webhook in background so MacroDroid can catch
 * JARVIS actions even when running in browser!
 */
export function fireMacroDroidWebhook(command: string, target = '', message = ''): void {
  if (typeof window === 'undefined') return;
  try {
    const url = `http://127.0.0.1:8080/jarvis?cmd=${encodeURIComponent(command)}&target=${encodeURIComponent(target)}&msg=${encodeURIComponent(message)}`;
    fetch(url, { mode: 'no-cors' }).catch(() => {
      // Expected to fail silently if MacroDroid webhook server isn't running
    });
  } catch (e) {
    // Silent fail
  }
}

/**
 * Gets the active Native Android Bridge interface (window.JarvisNative or window.AndroidBridge)
 */
export function getNativeBridge(): any {
  if (typeof window === 'undefined') return null;
  return (
    (window as any).JarvisAndroid ||
    (window as any).AndroidBridge ||
    (window as any).JarvisNative ||
    null
  );
}

/**
 * Executes a structured action returned by Gemini or parsed from local intents.
 * Implements 3 simultaneous paths:
 * 1. Native Android Bridge (executeAction / specific methods + Intent + Accessibility)
 * 2. MacroDroid Broadcast Intent + Local HTTP Webhook
 * 3. Browser zero-tap deep link / location.href redirect
 */
export function executeStructuredAction(action: StructuredAction): ActionExecutionResult {
  const timestamp = Date.now();
  const bridge = getNativeBridge();
  const type = (action.type || '').toUpperCase();
  const params = action.params || {};

  // 1. Try Native Android Bridge executeAction first if available
  if (bridge && typeof bridge.executeAction === 'function') {
    try {
      bridge.executeAction(JSON.stringify(action));
    } catch (e) {
      console.warn('NativeBridge executeAction warning:', e);
    }
  }

  // 2. Also trigger MacroDroid bridge
  fireMacroDroidWebhook(type, params.appName || params.recipientName || params.phoneNumber || params.query || '', params.messageText || params.message || '');

  switch (type) {
    case 'OPEN_APP': {
      const appName = (params.appName || params.query || '').trim();
      const packageName = (params.packageName || '').trim();

      if (bridge && typeof bridge.openApp === 'function') {
        try {
          bridge.openApp(packageName || appName);
        } catch (e) {}
      }

      // Browser deep-link fallbacks for popular apps
      const deepLinks: Record<string, string> = {
        instagram: 'instagram://app',
        whatsapp: 'whatsapp://app',
        youtube: 'vnd.youtube:',
        twitter: 'twitter://',
        x: 'twitter://',
        chrome: 'googlechrome://',
        maps: 'geo:0,0',
        calculator: 'calc:',
      };

      const matchedKey = Object.keys(deepLinks).find((k) => appName.toLowerCase().includes(k));
      if (!bridge && matchedKey && typeof window !== 'undefined') {
        window.location.href = deepLinks[matchedKey];
      }

      return {
        type: 'OPEN_APP',
        actionName: `Launch Application: ${appName}`,
        androidIntent: `PackageManager.getLaunchIntentForPackage("${packageName || appName}")`,
        androidPermissions: ['<queries><intent><action android:name="android.intent.action.MAIN"/></intent></queries>'],
        status: 'executed',
        feedbackText: `Directly launching ${appName} on device.`,
        timestamp,
        payload: { appName, packageName },
      };
    }

    case 'YOUTUBE_SEARCH_PLAY':
    case 'OPEN_YOUTUBE': {
      const query = (params.query || '').trim();
      const targetUrl = query
        ? `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`
        : 'https://www.youtube.com/';
      const deepLink = query
        ? `vnd.youtube://results?q=${encodeURIComponent(query)}`
        : 'vnd.youtube:';

      if (bridge && typeof bridge.openYouTube === 'function') {
        try {
          bridge.openYouTube(query);
        } catch (e) {}
      } else if (typeof window !== 'undefined') {
        // Zero-tap direct browser launch
        window.location.href = targetUrl;
      }

      return {
        type: 'YOUTUBE_SEARCH_PLAY',
        actionName: query ? `YouTube: "${query}"` : 'Open YouTube App',
        url: targetUrl,
        androidIntent: `Intent(Intent.ACTION_VIEW, Uri.parse("${deepLink}"), package="com.google.android.youtube")`,
        status: 'executed',
        feedbackText: query
          ? `Directly playing "${query}" on YouTube.`
          : 'Directly opening YouTube app.',
        timestamp,
        payload: { query, targetUrl },
      };
    }

    case 'WHATSAPP_SEND':
    case 'SEND_WHATSAPP': {
      const recipient = (params.recipientName || '').trim();
      const phone = (params.phoneNumber || '').trim();
      const message = (params.messageText || params.message || '').trim();
      const encodedMsg = encodeURIComponent(message);
      const whatsappUrl = phone
        ? `https://api.whatsapp.com/send?phone=${encodeURIComponent(phone)}&text=${encodedMsg}`
        : `https://api.whatsapp.com/send?text=${encodedMsg}`;
      const deepLink = phone
        ? `whatsapp://send?phone=${encodeURIComponent(phone)}&text=${encodedMsg}`
        : `whatsapp://send?text=${encodedMsg}`;

      if (bridge && typeof bridge.sendWhatsApp === 'function') {
        try {
          bridge.sendWhatsApp(recipient || phone, message);
        } catch (e) {}
      } else if (typeof window !== 'undefined') {
        window.location.href = deepLink;
      }

      return {
        type: 'WHATSAPP_SEND',
        actionName: `WhatsApp Message to ${recipient || phone || 'Contact'}`,
        url: whatsappUrl,
        androidIntent: `Intent(Intent.ACTION_VIEW, Uri.parse("${deepLink}"), package="com.whatsapp")`,
        androidPermissions: ['android.permission.READ_CONTACTS', 'JarvisAccessibilityService (Auto-Send)'],
        status: 'executed',
        feedbackText: `Sending WhatsApp message to ${recipient || phone}: "${message}".`,
        timestamp,
        payload: { recipient, phone, message },
      };
    }

    case 'MAKE_CALL':
    case 'CALL_PHONE': {
      const target = (params.phoneNumberOrName || params.phoneNumber || '').trim();
      const cleanNum = target.replace(/[^0-9+]/g, '');
      const telUrl = `tel:${cleanNum || target}`;

      if (bridge && typeof bridge.makeCall === 'function') {
        try {
          bridge.makeCall(target);
        } catch (e) {}
      } else if (typeof window !== 'undefined' && (cleanNum || target)) {
        window.location.href = telUrl;
      }

      return {
        type: 'MAKE_CALL',
        actionName: `Dial ${target}`,
        url: telUrl,
        androidIntent: `Intent(Intent.ACTION_CALL, Uri.parse("${telUrl}"))`,
        androidPermissions: ['android.permission.CALL_PHONE', 'android.permission.READ_CONTACTS'],
        status: 'executed',
        feedbackText: `Directly initiating phone call to ${target}.`,
        timestamp,
        payload: { target },
      };
    }

    case 'SET_ALARM': {
      const msg = params.message || 'JARVIS Alarm';
      const minutesFromNow = params.minutesFromNow || (params.hour !== undefined ? 0 : 5);

      if (bridge && typeof bridge.setAlarm === 'function') {
        try {
          bridge.setAlarm(msg, minutesFromNow);
        } catch (e) {}
      }

      return {
        type: 'SET_ALARM',
        actionName: `Alarm: ${msg}`,
        androidIntent: `Intent(AlarmClock.ACTION_SET_ALARM, message="${msg}", skipUi=true)`,
        status: 'executed',
        feedbackText: `Alarm scheduled silently: "${msg}".`,
        timestamp,
        payload: { msg, minutesFromNow },
      };
    }

    case 'SET_TIMER': {
      const seconds = params.seconds || 60;
      const msg = params.message || 'JARVIS Timer';

      return {
        type: 'SET_TIMER',
        actionName: `Timer: ${seconds}s`,
        androidIntent: `Intent(AlarmClock.ACTION_SET_TIMER, length=${seconds}, skipUi=true)`,
        status: 'executed',
        feedbackText: `Countdown timer set for ${seconds} seconds.`,
        timestamp,
        payload: { seconds, msg },
      };
    }

    case 'TOGGLE_TORCH':
    case 'TORCH_CONTROL': {
      const state = params.state || 'toggle';
      const isEnabled = state === 'on' ? true : state === 'off' ? false : true;

      if (bridge && typeof bridge.setTorchMode === 'function') {
        try {
          bridge.setTorchMode(isEnabled);
        } catch (e) {}
      } else if (typeof window !== 'undefined') {
        import('./audio').then((m) => m.toggleWebTorch(isEnabled)).catch(() => {});
      }

      return {
        type: 'TOGGLE_TORCH',
        actionName: `Flashlight ${state.toUpperCase()}`,
        androidIntent: 'CameraManager.setTorchMode(cameraId, state)',
        androidPermissions: ['android.permission.CAMERA'],
        status: 'executed',
        feedbackText: `Flashlight toggled ${state.toUpperCase()}.`,
        timestamp,
        payload: { state },
      };
    }

    case 'SYSTEM_SETTING':
    case 'OPEN_SETTINGS': {
      const setting = (params.setting || 'all').toLowerCase();
      return {
        type: 'SYSTEM_SETTING',
        actionName: `Device Setting: ${setting.toUpperCase()}`,
        androidIntent: `Intent(Settings.ACTION_${setting.toUpperCase()}_SETTINGS)`,
        androidPermissions: ['android.permission.WRITE_SETTINGS'],
        status: 'executed',
        feedbackText: `Opening ${setting} system configuration.`,
        timestamp,
        payload: { setting },
      };
    }

    case 'GOOGLE_SEARCH': {
      const query = (params.query || '').trim();
      const url = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
      if (!bridge && typeof window !== 'undefined') {
        window.location.href = url;
      }
      return {
        type: 'GOOGLE_SEARCH',
        actionName: `Google Search: "${query}"`,
        url,
        androidIntent: `Intent(Intent.ACTION_WEB_SEARCH, query="${query}")`,
        status: 'executed',
        feedbackText: `Searching Google for "${query}".`,
        timestamp,
        payload: { query, url },
      };
    }

    case 'OPEN_URL': {
      const rawUrl = (params.url || '').trim();
      const formattedUrl = rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`;
      if (!bridge && typeof window !== 'undefined') {
        window.location.href = formattedUrl;
      }
      return {
        type: 'OPEN_URL',
        actionName: `Open URL: ${rawUrl}`,
        url: formattedUrl,
        androidIntent: `Intent(Intent.ACTION_VIEW, Uri.parse("${formattedUrl}"))`,
        status: 'executed',
        feedbackText: `Opening ${formattedUrl}.`,
        timestamp,
        payload: { url: formattedUrl },
      };
    }

    case 'GLOBAL_ACTION': {
      const gesture = (params.action || 'BACK').toUpperCase();
      if (bridge && typeof bridge.performGlobalAction === 'function') {
        try {
          bridge.performGlobalAction(gesture);
        } catch (e) {}
      }
      return {
        type: 'GLOBAL_ACTION',
        actionName: `Device Gesture: ${gesture}`,
        androidIntent: `JarvisAccessibilityService.performGlobalAction(${gesture})`,
        status: 'executed',
        feedbackText: `Performed ${gesture} gesture navigation.`,
        timestamp,
        payload: { gesture },
      };
    }

    default:
      return {
        type,
        actionName: 'Device Command',
        status: 'executed',
        feedbackText: `Executed command: ${type}`,
        timestamp,
        payload: params,
      };
  }
}

/**
 * Legacy wrapper for CommandIntent compatibility
 */
export function executeJarvisAction(intent: CommandIntent): ActionExecutionResult {
  const structured: StructuredAction = {
    type: intent.type,
    params: {
      appName: intent.payload?.appName || intent.payload?.query,
      query: intent.payload?.query,
      recipientName: intent.payload?.recipientName,
      messageText: intent.payload?.messageText,
      phoneNumber: intent.payload?.phoneNumber,
      phoneNumberOrName: intent.payload?.phoneNumber || intent.payload?.recipientName,
      state: intent.payload?.torchState || 'toggle',
      reminderMinutes: intent.payload?.reminderMinutes,
      reminderText: intent.payload?.reminderText,
    },
  };
  return executeStructuredAction(structured);
}
