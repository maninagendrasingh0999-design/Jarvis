# JARVIS AI Assistant — Web Preview Source Code

Autonomous AI Assistant & Stark Voice HUD Web Application.

## Quick Start (Web Development)

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Environment Variables**:
   Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
   Add your Gemini API Key (`GEMINI_API_KEY`). Note that the app also includes the pre-configured default Gemini API key and allows setting/changing your key directly via the **🔑 API Key** button in the top bar.

3. **Start Development Server**:
   ```bash
   npm run dev
   ```
   The application will start on `http://localhost:3000`.

4. **Production Build**:
   ```bash
   npm run build
   ```

## Project Structure

- `index.html` — Web application entry HTML with Stark Blue HUD theme
- `src/App.tsx` — Main JARVIS state engine, continuous voice listening, Gemini 2.5 Flash caller, floating orb, HUD
- `src/index.tsx` & `src/main.tsx` — React DOM mount entry points
- `src/index.css` — Futuristic holographic glow & Tailwind styles
- `src/components/` — Modular HUD components (VoiceOrb, DeviceControls, CodingMaster, TradeMaster, CyberAuth, ApiKeyModal, etc.)
- `src/utils/` — Audio synth, intent parser, action executor, offline JARVIS fallback core
- `server.ts` — Full-stack Express server with Vite middleware integration and API routes
- `vite.config.ts` — Vite build and dev server configuration
- `package.json` — Dependencies and scripts
